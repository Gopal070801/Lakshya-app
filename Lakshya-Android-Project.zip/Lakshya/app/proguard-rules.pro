# Nothing reflective in this app; default Android + Compose rules are enough.
-dontwarn kotlin.**
