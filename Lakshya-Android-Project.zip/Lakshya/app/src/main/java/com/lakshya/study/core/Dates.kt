package com.lakshya.study.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.random.Random

/* Dates are kept as ISO strings ("2026-11-12") exactly like the original web app,
 * so backups stay compatible in both directions. */

val DOW = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
val DOW_LONG = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
val MON = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

fun pad2(n: Int): String = n.toString().padStart(2, '0')

fun parseD(s: String): LocalDate = LocalDate.parse(s)
fun addDays(s: String, n: Int): String = LocalDate.parse(s).plusDays(n.toLong()).toString()
fun dayDiff(a: String, b: String): Int = ChronoUnit.DAYS.between(LocalDate.parse(a), LocalDate.parse(b)).toInt()
fun dowOf(s: String): Int = LocalDate.parse(s).dayOfWeek.value - 1          // Mon = 0 … Sun = 6
fun weekStart(s: String): String = addDays(s, -dowOf(s))
fun dayOfMonth(s: String): Int = LocalDate.parse(s).dayOfMonth
fun monthIdx(s: String): Int = LocalDate.parse(s).monthValue - 1
fun yearOf(s: String): Int = LocalDate.parse(s).year

fun fmtD(s: String): String {
    val d = LocalDate.parse(s)
    return "${d.dayOfMonth} ${MON[d.monthValue - 1]}"
}

fun isValidDate(s: String): Boolean = s.length == 10 && runCatching { LocalDate.parse(s) }.isSuccess

fun zone(): ZoneId = ZoneId.systemDefault()

/** Date a timestamp belongs to, honouring the "day starts at" setting (night owls). */
fun dateOf(ts: Long, dayStartHours: Int): String =
    Instant.ofEpochMilli(ts - dayStartHours * 3_600_000L).atZone(zone()).toLocalDate().toString()

fun hourOf(ts: Long): Int = Instant.ofEpochMilli(ts).atZone(zone()).hour
fun minuteOf(ts: Long): Int = Instant.ofEpochMilli(ts).atZone(zone()).minute

fun noonOf(date: String): Long =
    LocalDate.parse(date).atStartOfDay(zone()).toInstant().toEpochMilli() + 12 * 3_600_000L

fun nowHM(nowMs: Long): String = pad2(hourOf(nowMs)) + ":" + pad2(minuteOf(nowMs))

/* ---------- number / duration formatting (match the JS helpers) ---------- */

fun fnum(x: Double, dec: Int): String {
    if (x.isNaN() || x.isInfinite()) return "0"
    val p = 10.0.pow(dec)
    var r = Math.round(x * p) / p
    if (r == 0.0) r = 0.0
    return if (r == floor(r) && abs(r) < 1e15) r.toLong().toString() else r.toString()
}

fun f1(x: Double): String = fnum(x, 1)
fun f2(x: Double): String = fnum(x, 2)
fun f1(x: Number): String = fnum(x.toDouble(), 1)
fun f2(x: Number): String = fnum(x.toDouble(), 2)

fun pct(a: Number, b: Number): Int = if (b.toDouble() != 0.0) Math.round(a.toDouble() / b.toDouble() * 100).toInt() else 0

fun fmtDur(secs: Number): String {
    val s = Math.round(secs.toDouble()).toInt()
    val h = s / 3600
    val m = s % 3600 / 60
    return if (h > 0) "${h}h ${m}m" else if (m > 0) "${m}m" else "${s}s"
}

fun fmtHrs(secs: Number): String = f1(secs.toDouble() / 3600) + "h"

/** 25:00 style clock. up=true rounds up (countdown), otherwise down (stopwatch). */
fun clock(secs: Double, up: Boolean): String {
    val s = Math.max(0.0, if (up) Math.ceil(secs) else Math.floor(secs)).toInt()
    val h = s / 3600
    val m = s % 3600 / 60
    val x = s % 60
    return (if (h > 0) "$h:${pad2(m)}" else pad2(m)) + ":" + pad2(x)
}

fun to12(t: String): String {
    if (t.isEmpty()) return ""
    val p = t.split(":")
    val h = p[0].toIntOrNull() ?: return t
    val m = p.getOrNull(1)?.toIntOrNull() ?: 0
    val hh = if (h % 12 == 0) 12 else h % 12
    return "$hh:${pad2(m)} ${if (h < 12) "AM" else "PM"}"
}

fun toMin(t: String): Int {
    val p = t.split(":")
    return (p[0].toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
}

fun uid(): String =
    java.lang.Long.toString(System.currentTimeMillis(), 36) + Random.nextInt(36 * 36 * 36 * 36).toString(36).padStart(4, '0')

fun <T> clamp(v: T, a: T, b: T): T where T : Comparable<T> = if (v < a) a else if (v > b) b else v
