package com.lakshya.study.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lakshya.study.LakshyaApp
import kotlin.concurrent.thread

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = (context.applicationContext as LakshyaApp).store
        val pending = goAsync()
        thread {
            try {
                when (intent.action) {
                    Notifier.ACTION_TIMER -> store.tickBlocking()
                    Notifier.ACTION_REMIND -> {
                        Notifier.showReminder(context, store.state.value)
                        Notifier.syncReminder(context, store.state.value.settings)   // schedule tomorrow
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = (context.applicationContext as LakshyaApp).store
        val s = store.state.value
        Notifier.syncReminder(context, s.settings)
        Notifier.syncTimer(context, s, System.currentTimeMillis())
    }
}
