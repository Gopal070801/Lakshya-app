package com.lakshya.study.core

/* Field names mirror the original Lakshya web app, so its "Backup" JSON can be restored here. */

object Status {
    const val TODO = "todo"
    const val LEARNING = "learning"
    const val DONE = "done"
}

object Kind {
    const val WRONG = "wrong"
    const val SKIP = "skip"
    const val NOTE = "note"
}

data class Profile(
    val name: String = "",
    val exam: String = "SSC MTS",
    val examDate: String = "",
    val dailyGoal: Int = 240,      // minutes
    val streakMin: Int = 30,       // minutes needed for a streak day
    val dayStart: Int = 0,         // hour at which "today" begins
    val target: Double = 0.0,
    val onboarded: Boolean = false
)

data class Subject(
    val id: String,
    val name: String,
    val short: String,
    val emoji: String,
    val color: String,
    val merit: Boolean = false,
    val archived: Boolean = false
)

data class Topic(
    val id: String,
    val sid: String,
    val name: String,
    val imp: Boolean = false,
    val status: String = Status.TODO,
    val conf: Int = 0,
    val rev: Int = 0,
    val last: String = "",
    val due: String = "",
    val notes: String = "",
    val created: Long = 0L,
    val doneOn: String = "",
    val demo: Boolean = false
)

data class Section(val total: Int, val correct: Int, val wrong: Int)

data class TestRec(
    val id: String,
    val name: String,
    val date: String,
    val type: String = "Full Mock",
    val mins: Int = 0,
    val created: Long = 0L,
    val sections: Map<String, Section> = emptyMap(),
    val demo: Boolean = false
)

data class Mistake(
    val id: String,
    val testId: String = "",          // "" = manual note
    val sid: String,
    val tid: String = "",
    val tn: String = "",
    val kind: String = Kind.WRONG,
    val reason: String = "silly",
    val q: String = "",
    val ans: String = "",
    val created: Long = 0L,
    val box: Int = 0,
    val due: String = "",
    val done: Boolean = false,
    val lastRev: String = "",
    val demo: Boolean = false
)

data class Session(
    val id: String,
    val date: String,
    val ts: Long,
    val secs: Int,
    val sid: String = "",
    val tid: String = "",
    val mode: String = "pomo",
    val dist: Int = 0,
    val manual: Boolean = false,
    val demo: Boolean = false
)

data class Task(
    val id: String,
    val date: String,
    val title: String,
    val sid: String = "",
    val tid: String = "",
    val est: Int = 30,
    val time: String = "",
    val done: Boolean = false,
    val created: Long = 0L,
    val kind: String = "",
    val doneAt: Long = 0L,
    val demo: Boolean = false
)

data class Block(
    val id: String,
    val days: List<Int>,
    val start: String,
    val end: String,
    val sid: String,
    val label: String = "",
    val demo: Boolean = false
)

data class Habit(
    val id: String,
    val emoji: String,
    val name: String,
    val days: Set<String> = emptySet(),
    val created: Long = 0L,
    val demo: Boolean = false
)

data class TimerState(
    val phase: String,            // focus | short | long
    val mode: String,             // pomo | free | break
    val planned: Int,             // seconds, 0 = stopwatch
    val startedAt: Long,
    val acc: Double,              // seconds accumulated before the current run
    val running: Boolean,
    val sid: String,
    val tid: String,
    val dist: Int,
    val sessionStart: Long
)

data class Cyc(val date: String = "", val n: Int = 0)

data class Pomo(
    val focus: Int = 25,
    val short: Int = 5,
    val long: Int = 15,
    val every: Int = 4,
    val autoBreak: Boolean = true
)

data class Settings(
    val theme: String = "system",
    val accent: String = "",          // "" = theme default, or "#aaaaaa,#bbbbbb", or "dynamic"
    val card: String = "soft",        // soft | outline | elev
    val radius: String = "normal",    // sharp | normal | round
    val font: String = "default",     // default | serif | mono
    val fs: String = "m",             // s | m | l
    val density: String = "cozy",     // cozy | compact
    val nav: String = "float",        // float | bar
    val motion: String = "full",      // full | lite | off
    val haptics: Boolean = true,
    val sound: Boolean = true,
    val wake: Boolean = true,
    val correct: Double = 1.0,
    val negative: Double = 0.25,
    val pomo: Pomo = Pomo(),
    // ---- new in the native app ----
    val ui: String = "oneui",         // oneui | coloros
    val remind: Boolean = false,
    val remindTime: String = "20:00"
)

data class AppState(
    val v: Int = 2,
    val profile: Profile = Profile(),
    val subjects: List<Subject> = emptyList(),
    val topics: List<Topic> = emptyList(),
    val tests: List<TestRec> = emptyList(),
    val mistakes: List<Mistake> = emptyList(),
    val sessions: List<Session> = emptyList(),
    val tasks: List<Task> = emptyList(),
    val blocks: List<Block> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val revLog: Map<String, Int> = emptyMap(),
    val timer: TimerState? = null,
    val cyc: Cyc = Cyc(),
    val badges: Map<String, String> = emptyMap(),
    val lvl: Int = 0,
    val lastSid: String = "",
    val settings: Settings = Settings()
)

val GHOST_SUBJECT = Subject("", "General", "General", "📚", "#8b95ae", merit = false)
