package com.lakshya.study.core

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/* ======================================================================
 *  All "business logic" of Lakshya as pure functions over AppState.
 *  `Snap` caches derived numbers for one (state, today) pair.
 * ====================================================================== */

// ---------------------------------------------------------------- small result types
data class SecStat(
    val total: Int, val correct: Int, val wrong: Int, val skip: Int, val att: Int,
    val acc: Double, val attPct: Double, val score: Double, val max: Double
)

data class TestStat(val secs: Map<String, SecStat>, val merit: Double, val meritMax: Double, val total: Double, val totalMax: Double)
data class Head(val score: Double, val max: Double, val label: String)
data class Agg(
    val total: Int, val correct: Int, val wrong: Int, val skip: Int, val att: Int,
    val score: Double, val max: Double, val n: Int, val acc: Double, val attPct: Double
)

data class SubProg(val n: Int, val todo: Int, val learning: Int, val done: Int, val pct: Int, val revised: Int, val due: Int)
data class Streak(val cur: Int, val best: Int)
data class Level(val level: Int, val xp: Int, val lo: Int, val hi: Int, val p: Double, val title: String)
data class MB(val n: Int, val p: Int)
data class Weak(val sid: String, val tid: String, val name: String, val n: Int, val r: Map<String, Int>, val top: String)
data class FocusArea(val topic: Topic, val score: Double, val why: List<String>)
data class Forecast(val text: String, val late: Boolean)
data class Insight(val emoji: String, val title: String, val desc: String)   // title may contain **bold**
data class BlockNow(val cur: Block?, val next: Block?)
data class Combo(val sid: String, val kind: String)

class BadgeDef(val id: String, val emoji: String, val name: String, val desc: String, val progress: (Snap) -> Pair<Double, Double>)

// ---------------------------------------------------------------- Snap
class Snap(val s: AppState, val today: String) {

    private val subById by lazy { s.subjects.associateBy { it.id } }
    private val topicById by lazy { s.topics.associateBy { it.id } }
    private val topicsBySid by lazy { s.topics.groupBy { it.sid } }

    fun sub(id: String): Subject = subById[id] ?: GHOST_SUBJECT
    fun subOrNull(id: String): Subject? = subById[id]
    fun topic(id: String): Topic? = if (id.isEmpty()) null else topicById[id]
    fun topicsOf(sid: String): List<Topic> = topicsBySid[sid] ?: emptyList()
    fun shortOf(sub: Subject): String = sub.short.ifEmpty { sub.name.take(10) }

    val activeSubs: List<Subject> by lazy { s.subjects.filter { !it.archived } }
    fun meritIds(all: Boolean = false): List<String> = s.subjects.filter { it.merit && (all || !it.archived) }.map { it.id }
    fun tName(m: Mistake): String = topic(m.tid)?.name ?: m.tn.ifEmpty { "Unknown" }

    val mc: Double get() = s.settings.correct
    val ng: Double get() = s.settings.negative

    // ---- topics ----
    fun isDue(t: Topic): Boolean = t.status == Status.DONE && t.due.isNotEmpty() && t.due <= today
    fun cardDue(m: Mistake): Boolean = !m.done && (m.due.isEmpty() || m.due <= today)

    val dueTopics: List<Topic> by lazy { s.topics.filter { isDue(it) && !sub(it.sid).archived } }
    val dueCards: List<Mistake> by lazy { s.mistakes.filter { cardDue(it) } }

    fun subProg(sid: String): SubProg {
        val ts = topicsOf(sid)
        var todo = 0; var learn = 0; var done = 0
        for (t in ts) when (t.status) { Status.DONE -> done++; Status.LEARNING -> learn++; else -> todo++ }
        val n = ts.size
        return SubProg(n, todo, learn, done, if (n > 0) Math.round((done + learn * 0.5) / n * 100).toInt() else 0,
            ts.count { it.rev > 0 }, ts.count { isDue(it) })
    }

    val remainingTopics: Int by lazy { s.topics.count { it.status != Status.DONE && !sub(it.sid).archived } }

    // ---- time / streak / xp ----
    val dayMap: Map<String, Int> by lazy {
        val m = HashMap<String, Int>()
        for (x in s.sessions) m[x.date] = (m[x.date] ?: 0) + x.secs
        m
    }
    fun dayMins(d: String): Int = (dayMap[d] ?: 0) / 60
    val totalSecs: Int by lazy { s.sessions.sumOf { it.secs } }
    val secsBySub: Map<String, Int> by lazy {
        val m = HashMap<String, Int>(); for (x in s.sessions) m[x.sid] = (m[x.sid] ?: 0) + x.secs; m
    }
    val secsByTopic: Map<String, Int> by lazy {
        val m = HashMap<String, Int>(); for (x in s.sessions) if (x.tid.isNotEmpty()) m[x.tid] = (m[x.tid] ?: 0) + x.secs; m
    }

    val streak: Streak by lazy {
        val need = max(1, s.profile.streakMin) * 60
        val ok = { d: String -> (dayMap[d] ?: 0) >= need }
        var cur = 0
        var d = today
        if (!ok(d)) d = addDays(d, -1)
        while (ok(d) && cur < 4000) { cur++; d = addDays(d, -1) }
        var best = 0; var run = 0; var prev: String? = null
        for (x in dayMap.keys.filter(ok).sorted()) {
            run = if (prev != null && dayDiff(prev, x) == 1) run + 1 else 1
            if (run > best) best = run
            prev = x
        }
        Streak(cur, max(best, cur))
    }

    fun habitStreak(h: Habit): Streak {
        var cur = 0
        var d = today
        if (!h.days.contains(d)) d = addDays(d, -1)
        while (h.days.contains(d) && cur < 4000) { cur++; d = addDays(d, -1) }
        var best = 0; var run = 0; var prev: String? = null
        for (x in h.days.sorted()) {
            run = if (prev != null && dayDiff(prev, x) == 1) run + 1 else 1
            if (run > best) best = run
            prev = x
        }
        return Streak(cur, max(best, cur))
    }

    val xp: Int by lazy {
        (totalSecs / 60) + s.tests.size * 30 + s.topics.count { it.status == Status.DONE } * 15 +
            s.topics.sumOf { it.rev } * 10 + s.tasks.count { it.done } * 8 +
            s.habits.sumOf { it.days.size } * 5 + s.revLog.values.sum() * 3
    }

    val level: Level by lazy {
        val x = xp
        val l = floorSqrt(x / 60.0) + 1
        val lo = 60 * (l - 1) * (l - 1)
        val hi = 60 * l * l
        Level(l, x, lo, hi, clamp((x - lo).toDouble() / (hi - lo), 0.0, 1.0), TITLES[min(TITLES.size - 1, (l - 1) / 2)])
    }

    private fun floorSqrt(v: Double): Int = Math.floor(sqrt(v)).toInt()

    // ---- tests / marks ----
    val sortedTests: List<TestRec> by lazy {
        s.tests.sortedWith(Comparator { a, b ->
            if (a.date == b.date) a.created.compareTo(b.created) else a.date.compareTo(b.date)
        })
    }

    fun secStat(x: Section): SecStat {
        val skip = max(0, x.total - x.correct - x.wrong)
        val att = x.correct + x.wrong
        return SecStat(x.total, x.correct, x.wrong, skip, att,
            if (att > 0) x.correct.toDouble() / att * 100 else 0.0,
            if (x.total > 0) att.toDouble() / x.total * 100 else 0.0,
            x.correct * mc - x.wrong * ng, x.total * mc)
    }

    fun testStat(t: TestRec): TestStat {
        val ms = meritIds(true).toSet()
        val secs = LinkedHashMap<String, SecStat>()
        var merit = 0.0; var meritMax = 0.0; var total = 0.0; var totalMax = 0.0
        for ((k, v) in t.sections) {
            val st = secStat(v)
            secs[k] = st
            total += st.score; totalMax += st.max
            if (ms.contains(k)) { merit += st.score; meritMax += st.max }
        }
        return TestStat(secs, merit, meritMax, total, totalMax)
    }

    fun headScore(t: TestRec): Head {
        val st = testStat(t)
        return if (st.meritMax > 0) Head(st.merit, st.meritMax, "Merit") else Head(st.total, st.totalMax, "Total")
    }

    fun agg(tests: List<TestRec>, keys: Collection<String>): Agg {
        var total = 0; var correct = 0; var wrong = 0; var skip = 0; var att = 0; var score = 0.0; var mx = 0.0
        for (t in tests) for (k in keys) {
            val sec = t.sections[k] ?: continue
            val st = secStat(sec)
            total += st.total; correct += st.correct; wrong += st.wrong; skip += st.skip; att += st.att; score += st.score; mx += st.max
        }
        return Agg(total, correct, wrong, skip, att, score, mx, tests.size,
            if (att > 0) correct.toDouble() / att * 100 else 0.0, if (total > 0) att.toDouble() / total * 100 else 0.0)
    }

    private val logged: Map<String, Int> by lazy {
        val m = HashMap<String, Int>()
        for (x in s.mistakes) if (x.testId.isNotEmpty()) { val k = x.testId + "|" + x.sid + "|" + x.kind; m[k] = (m[k] ?: 0) + 1 }
        m
    }
    fun loggedCount(testId: String, sid: String, kind: String): Int = logged[testId + "|" + sid + "|" + kind] ?: 0

    /** need = wrong+skip questions of the test, got = how many of them are logged. */
    fun logProgress(t: TestRec): Pair<Int, Int> {
        var need = 0; var got = 0
        for ((k, v) in t.sections) {
            val st = secStat(v)
            need += st.wrong + st.skip
            got += min(st.wrong, loggedCount(t.id, k, Kind.WRONG)) + min(st.skip, loggedCount(t.id, k, Kind.SKIP))
        }
        return need to got
    }

    fun pendingCombo(t: TestRec, sids: Collection<String>): Combo? {
        var best: Combo? = null
        for (k in sids.sortedByDescending { if (sub(it).merit) 1 else 0 }) {
            val sec = t.sections[k] ?: continue
            val st = secStat(sec)
            if (st.wrong > loggedCount(t.id, k, Kind.WRONG)) return Combo(k, Kind.WRONG)
            if (best == null && st.skip > loggedCount(t.id, k, Kind.SKIP)) best = Combo(k, Kind.SKIP)
        }
        return best
    }

    val mistakesByTopic: Map<String, MB> by lazy {
        val n = HashMap<String, Int>(); val p = HashMap<String, Int>()
        for (x in s.mistakes) {
            if (x.tid.isEmpty()) continue
            n[x.tid] = (n[x.tid] ?: 0) + 1
            if (!x.done) p[x.tid] = (p[x.tid] ?: 0) + 1
        }
        n.mapValues { (k, v) -> MB(v, p[k] ?: 0) }
    }

    fun topWeak(ms: List<Mistake>, n: Int): List<Weak> {
        class G(val sid: String, val tid: String, val name: String) { var n = 0; val r = LinkedHashMap<String, Int>() }
        val g = LinkedHashMap<String, G>()
        for (m in ms) {
            val k = m.sid + "|" + m.tid.ifEmpty { m.tn }
            val o = g.getOrPut(k) { G(m.sid, m.tid, tName(m)) }
            o.n++
            o.r[m.reason] = (o.r[m.reason] ?: 0) + 1
        }
        return g.values.sortedByDescending { it.n }.take(n).map { x ->
            Weak(x.sid, x.tid, x.name, x.n, x.r, x.r.entries.maxByOrNull { it.value }?.key ?: "silly")
        }
    }

    fun focusAreas(n: Int): List<FocusArea> {
        val mb = mistakesByTopic
        val ms = meritIds().toSet()
        val rows = ArrayList<FocusArea>()
        for (t in s.topics) {
            if (sub(t.sid).archived) continue
            val p = mb[t.id]?.p ?: 0
            if (t.status == Status.DONE && p == 0) continue
            var sc = 0.0
            val why = ArrayList<String>()
            if (p > 0) { sc += p * 3; why.add("$p galtiyan") }
            if (t.status == Status.TODO) { sc += 2; why.add("padha nahi") } else if (t.status == Status.LEARNING) { sc += 1; why.add("adhoora") }
            if (t.imp) { sc += 2; why.add("⭐ important") }
            if (t.conf in 1..2) { sc += 4 - t.conf; why.add("confidence kam") }
            if (ms.contains(t.sid)) sc *= 1.4
            if (sc > 0) rows.add(FocusArea(t, sc, why))
        }
        return rows.sortedByDescending { it.score }.take(n)
    }

    val bestAcc: Double by lazy { s.tests.maxOfOrNull { agg(listOf(it), it.sections.keys).acc } ?: 0.0 }

    // ---- planner ----
    fun blocksOn(date: String): List<Block> {
        val w = dowOf(date)
        return s.blocks.filter { it.days.contains(w) }.sortedBy { it.start }
    }

    fun blockNow(nowMs: Long): BlockNow {
        val bl = blocksOn(today)
        val n = nowHM(nowMs)
        return BlockNow(bl.firstOrNull { it.start <= n && n < it.end }, bl.firstOrNull { it.start > n })
    }

    fun tasksOn(date: String): List<Task> =
        s.tasks.filter { it.date == date }.sortedWith(
            compareBy<Task> { it.done }.thenBy { it.time.ifEmpty { "99" } }.thenBy { it.created }
        )

    // ---- syllabus forecast ----
    fun syllabusForecast(): Forecast {
        val all = s.topics.filter { !sub(it.sid).archived }
        val remain = all.count { it.status != Status.DONE }
        val recent = all.count { it.status == Status.DONE && it.doneOn.isNotEmpty() && dayDiff(it.doneOn, today) < 14 }
        if (remain == 0) return Forecast("🎉 Poora syllabus complete!", false)
        val hasDate = s.profile.examDate.isNotEmpty() && dayDiff(today, s.profile.examDate) > 0
        val need = if (hasDate) remain.toDouble() / dayDiff(today, s.profile.examDate) else 0.0
        if (recent == 0) {
            return Forecast(
                if (need > 0) "Exam tak roz ~${f1(need)} topics chahiye. Pichle 14 din me koi topic complete nahi hua."
                else "Topics complete karte jao, yahan forecast dikhega.", false)
        }
        val rate = recent / 14.0
        val days = ceil(remain / rate).toInt()
        val fin = addDays(today, days)
        var txt = "Is raftaar (${f1(rate)} topics/din) se syllabus ~${fmtD(fin)} tak khatam hoga."
        var late = false
        if (s.profile.examDate.isNotEmpty()) {
            val gap = dayDiff(fin, s.profile.examDate)
            txt += if (gap >= 0) " Exam se $gap din pehle ✅" else " Exam se ${-gap} din late ⚠️ (roz ~${f1(need)} topics chahiye)"
            late = gap < 0
        }
        return Forecast(txt, late)
    }
}

// ================================================================== revision helpers (pure)
fun Topic.withStatus(st: String, today: String): Topic {
    if (status == st) return this
    return when (st) {
        Status.DONE -> copy(status = st, doneOn = today).scheduled(today)
        Status.TODO -> copy(status = st, due = "", rev = 0, doneOn = "")
        else -> copy(status = st, due = "")
    }
}

fun Topic.scheduled(today: String): Topic = copy(due = if (rev >= INTS.size) "" else addDays(today, INTS[rev]))

fun Topic.markRevised(today: String): Topic =
    copy(rev = rev + 1, last = today, status = Status.DONE).scheduled(today)

fun Mistake.srGood(today: String): Mistake =
    if (box + 1 >= 5) copy(box = 5, done = true, due = "", lastRev = today)
    else copy(box = box + 1, due = addDays(today, BOX[box.coerceIn(0, BOX.size - 1)]), lastRev = today)

fun Mistake.srHard(today: String): Mistake = copy(due = addDays(today, 2), lastRev = today)
fun Mistake.srAgain(today: String): Mistake = copy(box = 0, done = false, due = addDays(today, 1), lastRev = today)

fun AppState.bumpRev(today: String, by: Int = 1): AppState = copy(revLog = revLog + (today to ((revLog[today] ?: 0) + by)))

// ================================================================== smart plan
fun smartPlan(snap: Snap, date: String, nowMs: Long): List<Task> {
    val s = snap.s
    val have = s.tasks.filter { it.date == date }.map { it.tid }.filter { it.isNotEmpty() }.toSet()
    val goal = max(60, s.profile.dailyGoal)
    val out = ArrayList<Task>()
    var est = 0
    fun push(title: String, sid: String, tid: String, e: Int, kind: String) {
        out.add(Task(uid() + out.size, date, title, sid, tid, e, "", false, nowMs + out.size, kind))
        est += e
    }
    snap.dueTopics.filter { !have.contains(it.id) }.sortedBy { it.due }.take(3)
        .forEach { push("🔁 Revise: " + it.name, it.sid, it.id, 20, "rev") }
    val nc = snap.dueCards.size
    if (nc > 0 && s.tasks.none { it.date == date && it.kind == "nb" }) push("🃏 Mistake notebook revise ($nc cards)", "", "", 15, "nb")
    val dl = if (s.profile.examDate.isNotEmpty()) dayDiff(date, s.profile.examDate) else 0
    val remain = snap.remainingTopics
    val want = if (dl > 0) ceil(remain.toDouble() / dl).toInt().coerceIn(1, 4) else 2
    val order = snap.activeSubs.sortedByDescending { if (it.merit) 1 else 0 }
    val q: List<MutableList<Topic>> = order.map { sb ->
        snap.topicsOf(sb.id).filter { it.status != Status.DONE && !have.contains(it.id) }
            .sortedWith(compareByDescending<Topic> { it.status == Status.LEARNING }.thenByDescending { it.imp })
            .toMutableList()
    }
    var picked = 0
    var guard = 0
    while (picked < want && q.any { it.isNotEmpty() } && guard++ < 50) {
        for (list in q) {
            if (picked >= want || list.isEmpty()) continue
            val t = list.removeAt(0)
            val e = if (t.status == Status.LEARNING) 30 else 45
            if (est + e > goal && out.size >= 3) { picked = want; break }
            push((if (t.status == Status.LEARNING) "📖 Complete karo: " else "📘 Naya topic: ") + t.name, t.sid, t.id, e, "new")
            picked++
        }
    }
    val lt = snap.sortedTests.lastOrNull()
    if ((lt == null || dayDiff(lt.date, date) >= 7) && est + 60 <= goal * 1.25 && s.subjects.isNotEmpty())
        push("📝 Ek mock test do aur galtiyan log karo", "", "", 60, "test")
    return out
}

// ================================================================== insights
fun insightsFor(snap: Snap, tests: List<TestRec>, ms: List<Mistake>, keys: Collection<String>): List<Insight> {
    val out = ArrayList<Insight>()
    val tot = ms.size
    if (tot == 0) return out
    val rc = ms.groupingBy { it.reason }.eachCount()
    val sorted = rc.entries.sortedByDescending { it.value }
    val (r0, n0) = sorted[0].let { it.key to it.value }
    val R0 = reasonOf(r0)
    out.add(Insight(R0.ico, "Sabse badi dikkat: **${R0.label}** (${pct(n0, tot)}%)", R0.fix))
    sorted.drop(1).take(2).forEach { (r, n) ->
        if (pct(n, tot) >= 20) { val R = reasonOf(r); out.add(Insight(R.ico, "**${R.label}** bhi ${pct(n, tot)}% hai", R.fix)) }
    }
    val skips = ms.count { it.kind == Kind.SKIP }
    if (pct(skips, tot) >= 35) out.add(Insight("⏭", "Attempt na kiye gaye questions ${pct(skips, tot)}% hain",
        "Jo aate hain wo chhutne nahi chahiye. Easy/GA-English pehle karo, phir baaki; sure ho to attempt karo."))
    val a = snap.agg(tests, keys)
    if (a.wrong > 0 && a.acc < 75 && tests.isNotEmpty())
        out.add(Insight("➖", "Galat answers se har test me ~**${f2(a.wrong * snap.ng / tests.size)}** marks kat rahe hain",
            "Accuracy 75% se upar laao; 50-50 me elimination ke baad hi mark karo."))
    val tw = snap.topWeak(ms, 1).firstOrNull()
    if (tw != null && tw.n >= 3) out.add(Insight("🎯", "**${tw.name}** me ${tw.n} galtiyan",
        "Is topic ka dedicated revision slot banao. Mukhya reason: ${reasonOf(tw.top).label}."))
    if (tests.size >= 3) {
        val sc = tests.map { snap.agg(listOf(it), keys).score }
        val lastV = sc.last()
        val avgPrev = sc.dropLast(1).sum() / (sc.size - 1)
        out.add(if (lastV >= avgPrev) Insight("📈", "Trend positive hai!", "Pichla score (${f2(lastV)}) pehle ke average (${f2(avgPrev)}) se upar hai. Isi routine ko pakde raho.")
        else Insight("📉", "Pichla test average se neeche gaya", "Pichla ${f2(lastV)} vs average ${f2(avgPrev)}. Sabse badi reason category par kaam karo."))
    }
    return out
}

// ================================================================== badges
val BADGES: List<BadgeDef> = listOf(
    BadgeDef("first", "🚀", "Shuruaat", "Pehla focus session") { it.s.sessions.size.toDouble() to 1.0 },
    BadgeDef("h10", "⏳", "10 Ghante", "Total 10 ghante padhai") { it.totalSecs / 3600.0 to 10.0 },
    BadgeDef("h50", "🔥", "50 Ghante", "Total 50 ghante padhai") { it.totalSecs / 3600.0 to 50.0 },
    BadgeDef("h100", "💎", "100 Ghante", "Total 100 ghante padhai") { it.totalSecs / 3600.0 to 100.0 },
    BadgeDef("h250", "👑", "250 Ghante", "Total 250 ghante padhai") { it.totalSecs / 3600.0 to 250.0 },
    BadgeDef("s3", "📅", "3 Din Streak", "Lagatar 3 din goal") { it.streak.best.toDouble() to 3.0 },
    BadgeDef("s7", "🗓", "7 Din Streak", "Lagatar 7 din goal") { it.streak.best.toDouble() to 7.0 },
    BadgeDef("s30", "🏔", "30 Din Streak", "Lagatar 30 din goal") { it.streak.best.toDouble() to 30.0 },
    BadgeDef("t1", "📝", "Pehla Test", "Pehla mock test add karo") { it.s.tests.size.toDouble() to 1.0 },
    BadgeDef("t5", "📚", "5 Tests", "5 mock tests complete") { it.s.tests.size.toDouble() to 5.0 },
    BadgeDef("t15", "🎯", "15 Tests", "15 mock tests complete") { it.s.tests.size.toDouble() to 15.0 },
    BadgeDef("t30", "🏆", "30 Tests", "30 mock tests complete") { it.s.tests.size.toDouble() to 30.0 },
    BadgeDef("acc", "🎖", "80% Accuracy", "Kisi test me 80%+ accuracy") { it.bestAcc to 80.0 },
    BadgeDef("top10", "✅", "10 Topics", "10 topics complete") { it.s.topics.count { t -> t.status == Status.DONE }.toDouble() to 10.0 },
    BadgeDef("top30", "🌟", "30 Topics", "30 topics complete") { it.s.topics.count { t -> t.status == Status.DONE }.toDouble() to 30.0 },
    BadgeDef("rev25", "🔁", "25 Revisions", "Topics/cards 25 baar revise") { (it.s.topics.sumOf { t -> t.rev } + it.s.revLog.values.sum()).toDouble() to 25.0 },
    BadgeDef("task25", "☑️", "25 Tasks", "25 planner tasks complete") { it.s.tasks.count { t -> t.done }.toDouble() to 25.0 },
    BadgeDef("hab7", "🌱", "Habit Hero", "Kisi habit ki 7 din streak") { (it.s.habits.maxOfOrNull { h -> it.habitStreak(h).best } ?: 0).toDouble() to 7.0 },
    BadgeDef("early", "🌅", "Early Bird", "Subah 6 baje se pehle session") { (if (it.s.sessions.any { x -> !x.manual && hourOf(x.ts) < 6 }) 1.0 else 0.0) to 1.0 },
    BadgeDef("owl", "🦉", "Night Owl", "Raat 11 baje ke baad session") { (if (it.s.sessions.any { x -> !x.manual && hourOf(x.ts) >= 23 }) 1.0 else 0.0) to 1.0 },
    BadgeDef("mara", "🏃", "Marathon", "Ek session me 2 ghante") { ((it.s.sessions.maxOfOrNull { x -> x.secs } ?: 0) / 60.0) to 120.0 },
    BadgeDef("lv5", "⭐", "Level 5", "Level 5 tak pahuncho") { it.level.level.toDouble() to 5.0 }
)

class ProgressResult(val state: AppState, val messages: List<String>)

/** Awards new badges / level-ups. Returns the same instance when nothing changed. */
fun checkProgress(s: AppState, today: String, silent: Boolean = false): ProgressResult {
    val snap = Snap(s, today)
    var badges = s.badges
    val msgs = ArrayList<String>()
    for (b in BADGES) {
        if (badges.containsKey(b.id)) continue
        val (c, t) = b.progress(snap)
        if (c >= t) {
            badges = badges + (b.id to today)
            if (!silent) msgs.add("🏆 Badge mila: ${b.name}")
        }
    }
    val lv = snap.level.level
    var out = s
    if (badges !== s.badges) out = out.copy(badges = badges)
    if (lv > s.lvl) {
        if (!silent && s.lvl > 0) msgs.add("⬆️ Level $lv unlock ho gaya!")
        out = out.copy(lvl = lv)
    }
    return ProgressResult(out, msgs)
}

// ================================================================== timer (timestamp based: process-death / screen-lock safe)
fun tElapsed(t: TimerState, now: Long): Double = t.acc + if (t.running) (now - t.startedAt) / 1000.0 else 0.0

/** Epoch millis when the current countdown phase ends, or null (paused / stopwatch). */
fun timerEndAt(t: TimerState?): Long? =
    if (t != null && t.running && t.planned > 0) t.startedAt + ((t.planned - t.acc) * 1000).toLong() else null

class TimerOut(val state: AppState, val message: String? = null, val phaseEnded: Boolean = false)

private fun logSession(s: AppState, t: TimerState, secs: Double): AppState {
    val ses = Session(uid(), dateOf(t.sessionStart, s.profile.dayStart), t.sessionStart, Math.round(secs).toInt(), t.sid, t.tid, t.mode, t.dist)
    return s.copy(sessions = s.sessions + ses)
}

fun timerStart(s: AppState, sid: String, tid: String, free: Boolean, now: Long): AppState {
    val p = s.settings.pomo
    val today = dateOf(now, s.profile.dayStart)
    val cyc = if (s.cyc.date != today) Cyc(today, 0) else s.cyc
    val t = TimerState("focus", if (free) "free" else "pomo", if (free) 0 else p.focus * 60, now, 0.0, true, sid, tid, 0, now)
    return s.copy(timer = t, cyc = cyc, lastSid = sid)
}

fun timerToggle(s: AppState, now: Long): AppState {
    val t = s.timer ?: return s
    return s.copy(timer = if (t.running) t.copy(acc = tElapsed(t, now), running = false) else t.copy(startedAt = now, running = true))
}

/** Manual "Finish": logs the session when ≥ 1 minute. */
fun timerFinish(s: AppState, now: Long): TimerOut {
    val t = s.timer ?: return TimerOut(s)
    val e = tElapsed(t, now)
    if (t.phase == "focus") {
        return if (e >= 60) TimerOut(logSession(s, t, e).copy(timer = null), "✓ ${fmtDur(e)} ki padhai log ho gayi")
        else TimerOut(s.copy(timer = null), "1 minute se kam tha, log nahi hua")
    }
    return TimerOut(s.copy(timer = null))
}

/** Called when the countdown reaches zero. */
fun timerFinishPhase(s: AppState, now: Long): TimerOut {
    val t = s.timer ?: return TimerOut(s)
    val p = s.settings.pomo
    val late = now - (t.startedAt + ((t.planned - t.acc) * 1000).toLong())
    if (t.phase == "focus") {
        var ns = logSession(s, t, t.planned.toDouble())
        val today = dateOf(now, s.profile.dayStart)
        var cyc = if (ns.cyc.date != today) Cyc(today, 0) else ns.cyc
        cyc = cyc.copy(n = cyc.n + 1)
        val long = cyc.n % p.every == 0
        val msg = "🎉 Focus complete! " + if (long) "Lamba break lo ☕" else "Chhota break lo ☕"
        ns = ns.copy(cyc = cyc)
        ns = if (p.autoBreak && late < 120_000) {
            ns.copy(timer = TimerState(if (long) "long" else "short", "break", (if (long) p.long else p.short) * 60, now, 0.0, true, t.sid, t.tid, 0, now))
        } else ns.copy(timer = null)
        return TimerOut(ns, msg, true)
    }
    return TimerOut(s.copy(timer = null), "Break khatam! Wapas padhai 💪", true)
}

/** Idempotent: finishes the phase only if it is really over. */
fun timerTick(s: AppState, now: Long): TimerOut {
    val t = s.timer ?: return TimerOut(s)
    if (t.running && t.planned > 0 && tElapsed(t, now) >= t.planned) return timerFinishPhase(s, now)
    return TimerOut(s)
}

// ================================================================== demo data
fun loadDemo(s0: AppState, now: Long): AppState {
    var s = s0
    if (s.tests.any { it.demo }) return s
    val dayStart = s.profile.dayStart
    val td = dateOf(now, dayStart)
    if (s.subjects.isEmpty()) { val pr = buildPreset(); s = s.copy(subjects = pr.subjects, topics = pr.topics) }
    var seed = 7L
    fun rnd(): Double { seed = seed * 16807L % 2147483647L; return seed.toDouble() / 2147483647.0 }
    fun <T> pick(a: List<T>): T = a[Math.floor(rnd() * a.size).toInt().coerceIn(0, a.size - 1)]
    fun <T> wpick(pairs: List<Pair<T, Int>>): T {
        var r = rnd() * pairs.sumOf { it.second }
        for ((v, w) in pairs) { r -= w; if (r <= 0) return v }
        return pairs[0].first
    }
    val subs = s.subjects.filter { !it.archived }
    var seq = 0

    // topics
    val topics = s.topics.map { t ->
        val r = rnd()
        if (t.status == Status.TODO && r < .55) {
            if (r < .35) t.copy(status = Status.DONE, demo = true, rev = Math.floor(rnd() * 4).toInt(),
                doneOn = addDays(td, -Math.floor(rnd() * 20).toInt()), due = addDays(td, Math.floor(rnd() * 8).toInt() - 3),
                conf = 1 + Math.floor(rnd() * 5).toInt())
            else t.copy(status = Status.LEARNING, demo = true)
        } else t
    }
    s = s.copy(topics = topics)
    fun topicsOf(sid: String) = s.topics.filter { it.sid == sid }

    val accB = mapOf("ga" to .5, "eng" to .62, "math" to .6, "reas" to .68)
    val totB = mapOf("ga" to 25, "eng" to 25, "math" to 20, "reas" to 20)
    val tests = ArrayList<TestRec>()
    val mistakes = ArrayList<Mistake>()
    for (i in 0 until 6) {
        val tid = uid() + i
        val secs = LinkedHashMap<String, Section>()
        for (sb in subs) {
            val total = totB[sb.id] ?: 20
            val att = Math.round(total * (.82 + rnd() * .14)).toInt()
            val acc = min(.92, (accB[sb.id] ?: .6) + i * .04 + (rnd() - .5) * .08)
            val correct = Math.round(att * acc).toInt()
            val wrong = att - correct
            val skip = total - att
            secs[sb.id] = Section(total, correct, wrong)
            val tps = topicsOf(sb.id)
            if (tps.isEmpty()) continue
            fun mk(kind: String) {
                val tp = if (rnd() < .55) tps[Math.floor(rnd() * min(5, tps.size)).toInt()] else pick(tps)
                val reason = if (kind == Kind.SKIP) wpick(listOf("notstudied" to 4, "time" to 3, "confused" to 2, "forgot" to 1))
                else if (sb.id == "ga" || sb.id == "eng") wpick(listOf("forgot" to 4, "notstudied" to 3, "silly" to 2, "confused" to 2, "guess" to 2))
                else wpick(listOf("silly" to 4, "time" to 2, "confused" to 2, "forgot" to 1))
                seq++
                mistakes.add(Mistake(uid() + seq, tid, sb.id, tp.id, tp.name, kind, reason, "", "", now + i * 1000L + seq, 0,
                    addDays(td, Math.floor(rnd() * 3).toInt() - 1), false, "", true))
            }
            for (j in 0 until wrong) mk(Kind.WRONG)
            for (j in 0 until skip) mk(Kind.SKIP)
        }
        tests.add(TestRec(tid, "Demo Mock ${i + 1}", addDays(td, -(5 - i) * 4 - 1), if (i % 3 == 2) "Sectional" else "Full Mock",
            70 + Math.floor(rnd() * 20).toInt(), now + i, secs, true))
    }
    listOf(
        listOf("ga", "Awards & Honours", "forgot", "Pehla Param Vir Chakra kisko mila?", "Major Somnath Sharma"),
        listOf("ga", "History – Modern & Freedom Struggle", "forgot", "Rowlatt Act kab pass hua?", "1919"),
        listOf("eng", "Idioms & Phrases", "forgot", "\"Once in a blue moon\" ka matlab?", "Bahut kam / kabhi-kabhi"),
        listOf("eng", "One Word Substitution", "forgot", "Kitaabein pasand karne wala vyakti?", "Bibliophile")
    ).forEachIndexed { i, (sid, tn, reason, q, ans) ->
        val tp = s.topics.firstOrNull { it.sid == sid && it.name == tn } ?: topicsOf(sid).firstOrNull()
        if (tp != null) mistakes.add(Mistake(uid() + "n" + i, "", sid, tp.id, tp.name, Kind.NOTE, reason, q, ans, now + 99999 + i, 0, td, false, "", true))
    }
    val sessions = ArrayList<Session>()
    if (subs.isNotEmpty()) for (i in 34 downTo 0) {
        val d = addDays(td, -i)
        if (rnd() < .22 && i > 0) continue
        val n = 1 + Math.floor(rnd() * 3).toInt()
        for (j in 0 until n) {
            val sb = pick(subs)
            val tps = topicsOf(sb.id)
            val hr = wpick(listOf(6 to 2, 7 to 3, 8 to 2, 10 to 1, 16 to 1, 19 to 3, 20 to 3, 21 to 2, 22 to 1))
            val ts = noonOf(d) - 12 * 3_600_000L + hr * 3_600_000L + Math.floor(rnd() * 50).toLong() * 60_000L
            if (ts > now) continue
            seq++
            sessions.add(Session(uid() + seq, dateOf(ts, dayStart), ts, (25 + Math.floor(rnd() * 4).toInt() * 10) * 60, sb.id,
                if (rnd() < .6 && tps.isNotEmpty()) pick(tps).id else "", "pomo", Math.floor(rnd() * 3).toInt(), false, true))
        }
    }
    val tasks = ArrayList<Task>()
    fun nt(date: String, title: String, sid: String, est: Int, done: Boolean) {
        seq++
        tasks.add(Task(uid() + seq, date, title, sid, "", est, "", done, now + seq, "", 0L, true))
    }
    nt(td, "📘 Percentage ke 20 questions", "math", 45, true); nt(td, "📖 Current Affairs: last 1 month", "ga", 40, false)
    nt(td, "🔁 Idioms revise karo", "eng", 20, false); nt(td, "📝 Sectional test (English)", "eng", 30, false)
    nt(addDays(td, -1), "📘 Polity notes", "ga", 45, true); nt(addDays(td, -1), "📘 Series practice", "reas", 30, true)
    nt(addDays(td, 1), "📘 Geography India", "ga", 45, false)
    val blocks = ArrayList(s.blocks)
    if (blocks.isEmpty()) {
        listOf(
            Triple(listOf(0, 1, 2, 3, 4), "06:00" to "08:00", "ga" to "GA reading"),
            Triple(listOf(0, 1, 2, 3, 4, 5), "19:00" to "20:30", "eng" to "English practice"),
            Triple(listOf(5, 6), "10:00" to "13:00", "math" to "Maths + Reasoning"),
            Triple(listOf(0, 2, 4), "21:00" to "22:00", "reas" to "Reasoning")
        ).forEach { (days, tm, sl) -> seq++; blocks.add(Block(uid() + seq, days, tm.first, tm.second, sl.first, sl.second, true)) }
    }
    val habits = ArrayList(s.habits)
    if (habits.isEmpty()) HABIT_SUG.take(3).forEach { (emoji, name) ->
        val days = HashSet<String>()
        for (i in 0 until 25) if (rnd() < .7) days.add(addDays(td, -i))
        seq++
        habits.add(Habit(uid() + seq, emoji, name, days, now, true))
    }
    return s.copy(
        tests = s.tests + tests, mistakes = s.mistakes + mistakes, sessions = s.sessions + sessions, tasks = s.tasks + tasks,
        blocks = blocks, habits = habits,
        profile = s.profile.copy(examDate = s.profile.examDate.ifEmpty { addDays(td, 60) })
    )
}

fun removeDemo(s: AppState): AppState = s.copy(
    tests = s.tests.filter { !it.demo }, mistakes = s.mistakes.filter { !it.demo }, sessions = s.sessions.filter { !it.demo },
    tasks = s.tasks.filter { !it.demo }, blocks = s.blocks.filter { !it.demo }, habits = s.habits.filter { !it.demo },
    topics = s.topics.map { if (it.demo) it.copy(status = Status.TODO, rev = 0, due = "", doneOn = "", conf = 0, demo = false) else it }
)

