package com.lakshya.study.ui.theme

import android.os.Build
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lakshya.study.core.Settings
import com.lakshya.study.core.hexInt
import com.lakshya.study.core.themeOf

@Immutable
class LColors(
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val text: Color,
    val sub: Color,
    val line: Color,
    val acc: Color,
    val acc2: Color,
    val accSoft: Color,
    val accText: Color,
    val onAcc: Color,
    val ok: Color,
    val bad: Color,
    val warn: Color,
    val skip: Color,
    val light: Boolean
) {
    val grad: Brush get() = Brush.linearGradient(listOf(acc, acc2))
}

@Immutable
class Dims(
    val card: Dp,        // big card corner
    val inner: Dp,       // chips / inputs / rows
    val pad: Dp,         // card padding
    val gap: Dp,         // gap between cards
    val coloros: Boolean,
    val floatNav: Boolean,
    val cardStyle: String
)

enum class Motion { Full, Lite, Off }

val LocalColors = staticCompositionLocalOf<LColors> { error("no theme") }
val LocalDims = staticCompositionLocalOf<Dims> { error("no dims") }
val LocalMotion = staticCompositionLocalOf { Motion.Full }
val LocalAppFont = staticCompositionLocalOf<FontFamily> { FontFamily.Default }

object Th {
    val c: LColors @Composable @ReadOnlyComposable get() = LocalColors.current
    val d: Dims @Composable @ReadOnlyComposable get() = LocalDims.current
    val motion: Motion @Composable @ReadOnlyComposable get() = LocalMotion.current
}

val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)

/** Animation spec honouring the user's "Animations" setting. */
@Composable
@ReadOnlyComposable
fun <T> tweenSpec(ms: Int = 300): FiniteAnimationSpec<T> = when (Th.motion) {
    Motion.Full -> tween(ms, easing = Emphasized)
    Motion.Lite -> tween(ms / 2, easing = Emphasized)
    Motion.Off -> snap()
}

private fun parse(h: String): Color = Color(hexInt(h))

private fun luminance(c: Color): Float = 0.299f * c.red + 0.587f * c.green + 0.114f * c.blue

@Composable
fun LakshyaTheme(st: Settings, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val th = themeOf(st.theme)
    val auto = th.id == "system"
    val light = if (auto) !sysDark else th.light
    val colors = remember(st.theme, st.accent, st.ui, sysDark) {
        // base accent
        var a = parse(th.acc)
        var b = parse(th.acc2)
        if (auto && st.ui == "coloros") { a = parse("#2FBF71"); b = parse("#1FB5D6") }
        if (st.accent == "dynamic" && Build.VERSION.SDK_INT >= 31) {
            val cs = if (light) dynamicLightColorScheme(ctx) else dynamicDarkColorScheme(ctx)
            a = cs.primary; b = cs.tertiary
        } else if (st.accent.contains(",")) {
            val p = st.accent.split(",")
            a = parse(p[0]); b = parse(p[1])
        }
        val bg = when {
            auto && light -> if (st.ui == "coloros") parse("#F5F6F8") else parse("#F4F4F6")
            auto -> if (st.ui == "coloros") parse("#0D0E10") else Color.Black
            else -> parse(th.bg)
        }
        val surface = if (light) Color.White else lerp(bg, Color.White, 0.075f)
        val surface2 = if (light) lerp(bg, Color.Black, 0.045f) else lerp(bg, Color.White, 0.14f)
        val accT = if (light) lerp(a, Color.Black, 0.30f) else a
        LColors(
            bg = bg, surface = surface, surface2 = surface2,
            text = if (light) Color(0xFF16192A) else Color(0xFFF0F2F8),
            sub = if (light) Color(0xFF6B7385) else Color(0xFF9AA3B8),
            line = if (light) Color(0x14000000) else Color(0x14FFFFFF),
            acc = a, acc2 = b, accSoft = a.copy(alpha = if (light) 0.13f else 0.18f), accText = accT,
            onAcc = if (luminance(a) > 0.62f) Color(0xFF0B0E17) else Color.White,
            ok = if (light) Color(0xFF16A34A) else Color(0xFF34D399),
            bad = if (light) Color(0xFFDC2626) else Color(0xFFF87171),
            warn = if (light) Color(0xFFD97706) else Color(0xFFFBBF24),
            skip = Color(0xFF8B95AE), light = light
        )
    }
    val dims = remember(st.ui, st.radius, st.density, st.nav, st.card) {
        val rs = when (st.radius) { "sharp" -> 0.55f; "round" -> 1.22f; else -> 1f }
        val coloros = st.ui == "coloros"
        val base = if (coloros) 20f else 26f
        val compact = st.density == "compact"
        Dims(
            card = (base * rs).dp, inner = ((if (coloros) 14f else 18f) * rs).dp,
            pad = if (compact) 12.dp else 16.dp, gap = if (compact) 10.dp else 14.dp,
            coloros = coloros, floatNav = st.nav == "float", cardStyle = st.card
        )
    }
    val font = when (st.font) { "serif" -> FontFamily.Serif; "mono" -> FontFamily.Monospace; else -> FontFamily.Default }
    val motion = when (st.motion) { "off" -> Motion.Off; "lite" -> Motion.Lite; else -> Motion.Full }
    val d = LocalDensity.current
    val mult = when (st.fs) { "s" -> 0.92f; "l" -> 1.12f; else -> 1f }
    val dens = remember(d, mult) { Density(d.density, d.fontScale * mult) }
    val sel = remember(colors) { TextSelectionColors(colors.acc, colors.acc.copy(alpha = 0.3f)) }

    CompositionLocalProvider(
        LocalColors provides colors, LocalDims provides dims, LocalMotion provides motion,
        LocalAppFont provides font, LocalDensity provides dens, LocalTextSelectionColors provides sel
    ) { content() }
}
