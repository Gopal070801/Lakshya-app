package com.lakshya.study.core

/**
 * JSON <-> AppState. The format is intentionally identical to the web app's backup file
 * (so old data can be restored here) and tolerant of missing / malformed fields.
 */
private typealias M = Map<String, Any?>

object Codec {

    // ------------------------------------------------------------------ helpers
    private fun Any?.obj(): M = (this as? Map<*, *>)?.entries?.associate { it.key.toString() to it.value } ?: emptyMap()
    private fun Any?.arr(): List<Any?> = (this as? List<*>) ?: emptyList()

    private fun M.s(k: String, d: String = ""): String = when (val v = this[k]) {
        null -> d
        is String -> v
        is Boolean -> v.toString()
        is Number -> if (v.toDouble() == Math.floor(v.toDouble())) v.toLong().toString() else v.toString()
        else -> d
    }

    private fun M.n(k: String, d: Double = 0.0): Double = when (val v = this[k]) {
        is Number -> v.toDouble().let { if (it.isNaN() || it.isInfinite()) d else it }
        is String -> v.toDoubleOrNull() ?: d
        is Boolean -> if (v) 1.0 else 0.0
        else -> d
    }

    private fun M.i(k: String, d: Int = 0): Int = n(k, d.toDouble()).toInt()
    private fun M.l(k: String, d: Long = 0L): Long = when (val v = this[k]) {
        is Long -> v
        is Number -> v.toLong()
        is String -> v.toLongOrNull() ?: d
        else -> d
    }

    private fun M.b(k: String, d: Boolean = false): Boolean = when (val v = this[k]) {
        is Boolean -> v
        is Number -> v.toDouble() != 0.0
        is String -> v == "true"
        else -> d
    }

    private fun M.date(k: String): String = s(k).let { if (isValidDate(it)) it else "" }
    private fun M.time(k: String, d: String): String =
        s(k).let { if (Regex("^\\d{1,2}:\\d{2}$").matches(it)) it else d }

    private val HEX = Regex("^#[0-9a-fA-F]{6}$")
    private fun M.color(k: String, d: String = "#7c9cff"): String = s(k).let { if (HEX.matches(it)) it else d }

    // ------------------------------------------------------------------ decode
    class DecodeException(msg: String) : Exception(msg)

    fun decode(text: String): AppState {
        val root: Any? = try { Json.parse(text) } catch (e: Exception) { throw DecodeException("Invalid JSON") }
        val m = root.obj()
        return when {
            m.containsKey("subjects") -> fromV2(m)
            m["tests"] is List<*> && m["mistakes"] is List<*> -> fromV1(m)
            else -> throw DecodeException("Not a Lakshya backup")
        }
    }

    /** Parse the app's own save file; falls back to defaults on any problem. */
    fun decodeOrDefault(text: String?): AppState =
        if (text.isNullOrBlank()) AppState() else try { decode(text) } catch (e: Exception) { AppState() }

    private fun fromV2(m: M): AppState {
        val d = AppState()
        val pr = m["profile"].obj()
        val st = m["settings"].obj()
        val po = st["pomo"].obj()
        val pd = d.profile
        val sd = d.settings
        val pod = sd.pomo
        val profile = Profile(
            name = pr.s("name", pd.name), exam = pr.s("exam", pd.exam), examDate = pr.date("examDate"),
            dailyGoal = pr.i("dailyGoal", pd.dailyGoal).coerceIn(1, 1440), streakMin = pr.i("streakMin", pd.streakMin).coerceIn(1, 1440),
            dayStart = pr.i("dayStart", 0).coerceIn(0, 8), target = pr.n("target", 0.0).coerceAtLeast(0.0),
            onboarded = pr.b("onboarded", false)
        )
        val pomo = Pomo(
            focus = po.i("focus", pod.focus).coerceIn(1, 240), short = po.i("short", pod.short).coerceIn(1, 120),
            long = po.i("long", pod.long).coerceIn(1, 180), every = po.i("every", pod.every).coerceIn(1, 20),
            autoBreak = po.b("autoBreak", pod.autoBreak)
        )
        val settings = Settings(
            theme = st.s("theme", sd.theme).let { id -> if (THEMES.any { it.id == id }) id else sd.theme },
            accent = st.s("accent", ""), card = st.s("card", sd.card), radius = st.s("radius", sd.radius),
            font = st.s("font", sd.font), fs = st.s("fs", sd.fs), density = st.s("density", sd.density),
            nav = st.s("nav", sd.nav), motion = st.s("motion", sd.motion), haptics = st.b("haptics", sd.haptics),
            sound = st.b("sound", sd.sound), wake = st.b("wake", sd.wake), correct = st.n("correct", sd.correct),
            negative = st.n("negative", sd.negative), pomo = pomo, ui = st.s("ui", sd.ui),
            remind = st.b("remind", false), remindTime = st.time("remindTime", sd.remindTime)
        )
        val subjects = m["subjects"].arr().map { it.obj() }.filter { it.s("id").isNotEmpty() || it.s("name").isNotEmpty() }.map { o ->
            val name = o.s("name", "Subject")
            Subject(o.s("id").ifEmpty { uid() }, name, o.s("short").ifEmpty { name.take(10) }, o.s("emoji", "📘"),
                o.color("color"), o.b("merit"), o.b("archived"))
        }
        val topics = m["topics"].arr().map { it.obj() }.map { o ->
            Topic(
                id = o.s("id").ifEmpty { uid() }, sid = o.s("sid"), name = o.s("name", "Topic"), imp = o.b("imp"),
                status = o.s("status").let { if (it == Status.LEARNING || it == Status.DONE) it else Status.TODO },
                conf = o.i("conf").coerceIn(0, 5), rev = o.i("rev").coerceAtLeast(0), last = o.date("last"), due = o.date("due"),
                notes = o.s("notes"), created = o.l("created"), doneOn = o.date("doneOn"), demo = o.b("demo")
            )
        }
        val tests = m["tests"].arr().map { it.obj() }.map { o ->
            val secs = LinkedHashMap<String, Section>()
            for ((k, v) in o["sections"].obj()) {
                val sv = v.obj()
                secs[k] = Section(sv.i("total").coerceAtLeast(0), sv.i("correct").coerceAtLeast(0), sv.i("wrong").coerceAtLeast(0))
            }
            TestRec(o.s("id").ifEmpty { uid() }, o.s("name", "Test"), o.date("date").ifEmpty { todayIso() },
                o.s("type").ifEmpty { "Full Mock" }, o.i("mins").coerceAtLeast(0), o.l("created"), secs, o.b("demo"))
        }
        val mistakes = m["mistakes"].arr().map { it.obj() }.map { o ->
            Mistake(
                id = o.s("id").ifEmpty { uid() }, testId = o.s("testId"), sid = o.s("sid"), tid = o.s("tid"), tn = o.s("tn"),
                kind = o.s("kind").let { if (it == Kind.SKIP || it == Kind.NOTE) it else Kind.WRONG },
                reason = o.s("reason").let { r -> if (REASON_KEYS.contains(r)) r else "silly" },
                q = o.s("q"), ans = o.s("ans"), created = o.l("created"), box = o.i("box").coerceIn(0, 5), due = o.date("due"),
                done = o.b("done"), lastRev = o.date("lastRev"), demo = o.b("demo")
            )
        }
        val sessions = m["sessions"].arr().map { it.obj() }.map { o ->
            val ts = o.l("ts")
            Session(o.s("id").ifEmpty { uid() }, o.date("date").ifEmpty { dateOf(ts, 0) }, ts, o.i("secs").coerceAtLeast(0),
                o.s("sid"), o.s("tid"), o.s("mode", "pomo"), o.i("dist"), o.b("manual"), o.b("demo"))
        }
        val tasks = m["tasks"].arr().map { it.obj() }.map { o ->
            Task(o.s("id").ifEmpty { uid() }, o.date("date").ifEmpty { todayIso() }, o.s("title", "Task"), o.s("sid"), o.s("tid"),
                o.i("est", 30), o.s("time"), o.b("done"), o.l("created"), o.s("kind"), o.l("doneAt"), o.b("demo"))
        }
        val blocks = m["blocks"].arr().map { it.obj() }.map { o ->
            val days = o["days"].arr().mapNotNull { (it as? Number)?.toInt() }.filter { it in 0..6 }.distinct().sorted()
            Block(o.s("id").ifEmpty { uid() }, days.ifEmpty { listOf(0) }, o.time("start", "06:00"), o.time("end", "08:00"),
                o.s("sid"), o.s("label"), o.b("demo"))
        }
        val habits = m["habits"].arr().map { it.obj() }.map { o ->
            val days = o["days"].obj().filter { (k, v) -> isValidDate(k) && v != null && v != false && v != 0L && v != 0.0 }.keys
            Habit(o.s("id").ifEmpty { uid() }, o.s("emoji", "📰"), o.s("name", "Habit"), days.toSet(), o.l("created"), o.b("demo"))
        }
        val revLog = LinkedHashMap<String, Int>()
        for ((k, v) in m["revLog"].obj()) if (isValidDate(k)) revLog[k] = ((v as? Number)?.toInt() ?: 0)
        val badges = LinkedHashMap<String, String>()
        for ((k, v) in m["badges"].obj()) badges[k] = (v as? String) ?: ""
        val cy = m["cyc"].obj()
        val tm = m["timer"].obj()
        val timer = if (tm.isNotEmpty() && tm.containsKey("startedAt")) TimerState(
            phase = tm.s("phase", "focus"), mode = tm.s("mode", "pomo"), planned = tm.i("planned"),
            startedAt = tm.l("startedAt"), acc = tm.n("acc"), running = tm.b("running"), sid = tm.s("sid"),
            tid = tm.s("tid"), dist = tm.i("dist"), sessionStart = tm.l("sessionStart")
        ) else null

        return AppState(
            v = 2, profile = profile, subjects = subjects, topics = topics, tests = tests, mistakes = mistakes,
            sessions = sessions, tasks = tasks, blocks = blocks, habits = habits, revLog = revLog, timer = timer,
            cyc = Cyc(cy.date("date"), cy.i("n")), badges = badges, lvl = m.i("lvl"), lastSid = m.s("lastSid"), settings = settings
        )
    }

    /** Old "MTS Tracker" format (v1). */
    private fun fromV1(o: M): AppState {
        val pr = buildPreset()
        val topics = ArrayList(pr.topics)
        val os = o["settings"].obj()
        val d = AppState()
        val merit = os["merit"].obj()
        val subjects = pr.subjects.map { s -> if (merit.containsKey(s.id)) s.copy(merit = merit.b(s.id)) else s }
        fun find(sid: String, name: String): Topic {
            val t = topics.firstOrNull { it.sid == sid && (it.name == name || it.name.startsWith(name)) }
            if (t != null) return t
            val nt = mkTopic(sid, name)
            topics.add(nt)
            return nt
        }
        val tests = o["tests"].arr().map { it.obj() }.map { t ->
            val secs = LinkedHashMap<String, Section>()
            for ((k, v) in t["sections"].obj()) {
                val sv = v.obj()
                secs[k] = Section(sv.i("total"), sv.i("correct"), sv.i("wrong"))
            }
            TestRec(t.s("id").ifEmpty { uid() }, t.s("name", "Test"), t.date("date").ifEmpty { todayIso() }, "Full Mock", 0,
                t.l("created"), secs, t.b("demo"))
        }
        val td = todayIso()
        val mistakes = o["mistakes"].arr().map { it.obj() }.map { m ->
            val sec = m.s("sec")
            val tp = find(sec, m.s("topic"))
            Mistake(m.s("id").ifEmpty { uid() }, m.s("testId"), sec, tp.id, m.s("topic"),
                m.s("kind").let { if (it == Kind.SKIP || it == Kind.NOTE) it else Kind.WRONG },
                m.s("reason").let { r -> if (REASON_KEYS.contains(r)) r else "silly" },
                m.s("q"), m.s("ans"), m.l("created"), 0, td, m.b("done"), "", m.b("demo"))
        }
        val revLog = LinkedHashMap<String, Int>()
        for ((k, v) in o["revLog"].obj()) if (isValidDate(k)) revLog[k] = ((v as? Number)?.toInt() ?: 0)
        return d.copy(
            profile = d.profile.copy(examDate = os.date("examDate"), target = os.n("target"), onboarded = true),
            subjects = subjects, topics = topics, tests = tests, mistakes = mistakes, revLog = revLog,
            settings = d.settings.copy(
                correct = os.n("correct", 1.0), negative = os.n("negative", 0.25),
                theme = if (os.s("theme") == "light") "frost" else "midnight",
                haptics = os.b("haptics", true), motion = if (os.b("lite")) "lite" else "full"
            )
        )
    }

    private fun todayIso(): String = dateOf(System.currentTimeMillis(), 0)

    // ------------------------------------------------------------------ encode
    fun encode(s: AppState): String = Json.write(toMap(s))

    private fun nz(v: String): String? = if (v.isEmpty()) null else v

    fun toMap(s: AppState): Map<String, Any?> {
        val st = s.settings
        val m = LinkedHashMap<String, Any?>()
        m["v"] = 2
        m["profile"] = linkedMapOf<String, Any?>(
            "name" to s.profile.name, "exam" to s.profile.exam, "examDate" to s.profile.examDate,
            "dailyGoal" to s.profile.dailyGoal, "streakMin" to s.profile.streakMin, "dayStart" to s.profile.dayStart,
            "target" to s.profile.target, "onboarded" to s.profile.onboarded
        )
        m["subjects"] = s.subjects.map {
            linkedMapOf<String, Any?>("id" to it.id, "name" to it.name, "short" to it.short, "emoji" to it.emoji,
                "color" to it.color, "merit" to it.merit, "archived" to it.archived)
        }
        m["topics"] = s.topics.map {
            linkedMapOf<String, Any?>("id" to it.id, "sid" to it.sid, "name" to it.name, "imp" to it.imp, "status" to it.status,
                "conf" to it.conf, "rev" to it.rev, "last" to it.last, "due" to it.due, "notes" to it.notes,
                "created" to it.created, "doneOn" to it.doneOn).also { mm -> if (it.demo) mm["demo"] = true }
        }
        m["tests"] = s.tests.map { t ->
            linkedMapOf<String, Any?>("id" to t.id, "name" to t.name, "date" to t.date, "type" to t.type, "mins" to t.mins,
                "created" to t.created,
                "sections" to t.sections.entries.associate { (k, v) -> k to linkedMapOf<String, Any?>("total" to v.total, "correct" to v.correct, "wrong" to v.wrong) }
            ).also { mm -> if (t.demo) mm["demo"] = true }
        }
        m["mistakes"] = s.mistakes.map {
            linkedMapOf<String, Any?>("id" to it.id, "testId" to nz(it.testId), "sid" to it.sid, "tid" to it.tid, "tn" to it.tn,
                "kind" to it.kind, "reason" to it.reason, "q" to it.q, "ans" to it.ans, "created" to it.created,
                "box" to it.box, "due" to it.due, "done" to it.done, "lastRev" to it.lastRev).also { mm -> if (it.demo) mm["demo"] = true }
        }
        m["sessions"] = s.sessions.map {
            linkedMapOf<String, Any?>("id" to it.id, "date" to it.date, "ts" to it.ts, "secs" to it.secs, "sid" to it.sid,
                "tid" to it.tid, "mode" to it.mode, "dist" to it.dist).also { mm ->
                if (it.manual) mm["manual"] = true
                if (it.demo) mm["demo"] = true
            }
        }
        m["tasks"] = s.tasks.map {
            linkedMapOf<String, Any?>("id" to it.id, "date" to it.date, "title" to it.title, "sid" to it.sid, "tid" to it.tid,
                "est" to it.est, "time" to it.time, "done" to it.done, "created" to it.created).also { mm ->
                if (it.kind.isNotEmpty()) mm["kind"] = it.kind
                if (it.doneAt != 0L) mm["doneAt"] = it.doneAt
                if (it.demo) mm["demo"] = true
            }
        }
        m["blocks"] = s.blocks.map {
            linkedMapOf<String, Any?>("id" to it.id, "days" to it.days, "start" to it.start, "end" to it.end, "sid" to it.sid,
                "label" to it.label).also { mm -> if (it.demo) mm["demo"] = true }
        }
        m["habits"] = s.habits.map { h ->
            linkedMapOf<String, Any?>("id" to h.id, "emoji" to h.emoji, "name" to h.name,
                "days" to h.days.sorted().associateWith { 1 }, "created" to h.created).also { mm -> if (h.demo) mm["demo"] = true }
        }
        m["revLog"] = s.revLog
        m["timer"] = s.timer?.let {
            linkedMapOf<String, Any?>("phase" to it.phase, "mode" to it.mode, "planned" to it.planned, "startedAt" to it.startedAt,
                "acc" to it.acc, "running" to it.running, "sid" to it.sid, "tid" to it.tid, "dist" to it.dist,
                "sessionStart" to it.sessionStart)
        }
        m["cyc"] = linkedMapOf<String, Any?>("date" to s.cyc.date, "n" to s.cyc.n)
        m["badges"] = s.badges
        m["lvl"] = s.lvl
        m["lastSid"] = s.lastSid
        m["settings"] = linkedMapOf<String, Any?>(
            "theme" to st.theme, "accent" to st.accent, "card" to st.card, "radius" to st.radius, "font" to st.font, "fs" to st.fs,
            "density" to st.density, "nav" to st.nav, "motion" to st.motion, "haptics" to st.haptics, "sound" to st.sound,
            "wake" to st.wake, "correct" to st.correct, "negative" to st.negative,
            "pomo" to linkedMapOf<String, Any?>("focus" to st.pomo.focus, "short" to st.pomo.short, "long" to st.pomo.long,
                "every" to st.pomo.every, "autoBreak" to st.pomo.autoBreak),
            "ui" to st.ui, "remind" to st.remind, "remindTime" to st.remindTime
        )
        return m
    }
}
