package com.lakshya.study.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.lakshya.study.core.Snap
import com.lakshya.study.core.clock
import com.lakshya.study.core.tElapsed
import com.lakshya.study.data.Store
import com.lakshya.study.data.UiEvent
import com.lakshya.study.ui.components.BottomNav
import com.lakshya.study.ui.components.ConfirmHost
import com.lakshya.study.ui.components.Fab
import com.lakshya.study.ui.components.NAV_BAR_H
import com.lakshya.study.ui.components.NAV_FLOAT_H
import com.lakshya.study.ui.components.SheetHost
import com.lakshya.study.ui.components.ToastHost
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.pressable
import com.lakshya.study.ui.screens.AnalysisScreen
import com.lakshya.study.ui.screens.BadgesScreen
import com.lakshya.study.ui.screens.FlashcardOverlay
import com.lakshya.study.ui.screens.FocusScreen
import com.lakshya.study.ui.screens.HabitsScreen
import com.lakshya.study.ui.screens.HomeScreen
import com.lakshya.study.ui.screens.LookScreen
import com.lakshya.study.ui.screens.NotebookScreen
import com.lakshya.study.ui.screens.Onboarding
import com.lakshya.study.ui.screens.PlanScreen
import com.lakshya.study.ui.screens.SettingsScreen
import com.lakshya.study.ui.screens.StatsScreen
import com.lakshya.study.ui.screens.SubjectScreen
import com.lakshya.study.ui.screens.SyllabusScreen
import com.lakshya.study.ui.screens.TestDetailScreen
import com.lakshya.study.ui.screens.TestsScreen
import com.lakshya.study.ui.screens.TimetableScreen
import com.lakshya.study.ui.sheets.SheetContent
import com.lakshya.study.ui.theme.Emphasized
import com.lakshya.study.ui.theme.LakshyaTheme
import com.lakshya.study.ui.theme.Motion
import com.lakshya.study.ui.theme.Th

private data class NavKey(val depth: Int, val dest: Dest)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun LakshyaRoot(store: Store) {
    val state by store.state.collectAsState()
    val today by store.today.collectAsState()
    val snap = remember(state, today) { Snap(state, today) }
    val ui = remember { Ui(store) }

    LakshyaTheme(state.settings) {
        val c = Th.c
        val ctx = LocalContext.current
        val view = LocalView.current
        val haptic = LocalHapticFeedback.current
        ui.haptic = haptic
        ui.hapticsOn = state.settings.haptics

        // system bars follow the in-app theme (not only the system theme)
        val light = c.light
        SideEffect {
            val w = ctx.findActivity()?.window
            if (w != null) {
                val ctl = WindowCompat.getInsetsController(w, view)
                ctl.isAppearanceLightStatusBars = light
                ctl.isAppearanceLightNavigationBars = light
            }
        }
        // keep the screen on while a timer is running
        val keepOn = state.settings.wake && state.timer?.running == true
        DisposableEffect(keepOn) {
            val w = ctx.findActivity()?.window
            if (keepOn) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }

        // notification permission (Android 13+)
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        ui.askNotif = {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        LaunchedEffect(Unit) {
            store.events.collect { e ->
                when (e) {
                    is UiEvent.Toast -> ui.toast(e.msg, e.type)
                    is UiEvent.Alert -> ui.strongHaptic()
                }
            }
        }
        val req by store.openRequest.collectAsState()
        LaunchedEffect(req, state.profile.onboarded) {
            val r = req
            if (r != null && state.profile.onboarded) {
                ui.revise = null; ui.sheet = null
                when (r) {
                    "focus" -> ui.tab(Dest.Focus)
                    "test" -> { ui.tab(Dest.Tests); ui.open(Sheet.TestForm(null)) }
                    "notebook" -> ui.tab(Dest.Notebook)
                }
                store.openRequest.value = null
            }
        }
        LaunchedEffect(ui.toastMsg) {
            val t = ui.toastMsg
            if (t != null) { kotlinx.coroutines.delay(2400); if (ui.toastMsg === t) ui.toastMsg = null }
        }

        BackHandler(enabled = ui.hasOverlay || ui.stack.size > 1 || ui.top != Dest.Home) { ui.back() }

        val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val navBlock = (if (state.settings.nav == "float") NAV_FLOAT_H + 8.dp else NAV_BAR_H) + navInset

        CompositionLocalProvider(
            LocalSnap provides snap, LocalUi provides ui, LocalStore provides store, LocalBottomPad provides navBlock
        ) {
            val onboarded = state.profile.onboarded
            Box(Modifier.fillMaxSize().background(c.bg)) {
                val key = NavKey(ui.stack.size, ui.top)
                val motion = Th.motion
                AnimatedContent(
                    targetState = key,
                    transitionSpec = {
                        if (motion == Motion.Off) ContentTransform(EnterTransition.None, ExitTransition.None)
                        else {
                            val ms = if (motion == Motion.Lite) 180 else 340
                            val push = targetState.depth > initialState.depth
                            val pop = targetState.depth < initialState.depth
                            when {
                                push -> (slideInHorizontally(tween(ms, easing = Emphasized)) { it / 4 } + fadeIn(tween(ms * 2 / 3))) togetherWith
                                    (slideOutHorizontally(tween(ms, easing = Emphasized)) { -it / 6 } + fadeOut(tween(ms / 2)))
                                pop -> (slideInHorizontally(tween(ms, easing = Emphasized)) { -it / 6 } + fadeIn(tween(ms * 2 / 3))) togetherWith
                                    (slideOutHorizontally(tween(ms, easing = Emphasized)) { it / 4 } + fadeOut(tween(ms / 2)))
                                else -> (fadeIn(tween(ms * 2 / 3, delayMillis = ms / 8)) + scaleIn(tween(ms, easing = Emphasized), initialScale = 0.97f)) togetherWith
                                    fadeOut(tween(ms / 3))
                            }
                        }
                    },
                    label = "nav", modifier = Modifier.fillMaxSize()
                ) { k ->
                    Box(Modifier.fillMaxSize().background(c.bg)) { ScreenFor(k.dest) }
                }

                if (onboarded) {
                    // floating action button
                    val fab: (() -> Unit)? = fabFor(ui, snap)
                    AnimatedVisibility(
                        fab != null && ui.revise == null, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = navBlock + 12.dp),
                        enter = fadeIn(tween(200)) + scaleIn(tween(260, easing = Emphasized), initialScale = 0.6f),
                        exit = fadeOut(tween(120))
                    ) { Fab({ ui.tick(); fab?.invoke() }) }

                    // mini timer
                    val timer = state.timer
                    AnimatedVisibility(
                        timer != null && ui.top != Dest.Focus && ui.revise == null,
                        modifier = Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = navBlock + 14.dp),
                        enter = fadeIn(tween(200)) + slideInVertically(tween(260, easing = Emphasized)) { it },
                        exit = fadeOut(tween(150)) + slideOutVertically(tween(180)) { it }
                    ) { MiniTimer(store, ui) }

                    AnimatedVisibility(
                        ui.revise == null, modifier = Modifier.align(Alignment.BottomCenter),
                        enter = fadeIn(tween(160)), exit = fadeOut(tween(120))
                    ) { BottomNav(ui.top.tab, { t -> ui.tick(); ui.tab(tabRoot(t)) }) }
                }

                // flashcard revision (full screen)
                AnimatedVisibility(
                    ui.revise != null, enter = slideInVertically(tween(340, easing = Emphasized)) { it } + fadeIn(tween(200)),
                    exit = slideOutVertically(tween(260, easing = Emphasized)) { it } + fadeOut(tween(160))
                ) {
                    val ids = ui.revise
                    if (ids != null) FlashcardOverlay(ids) { ui.revise = null }
                }

                SheetHost(ui.sheet, onDismiss = { ui.closeSheet() }) { s -> SheetContent(s) }
                ConfirmHost(ui.confirmReq, onDismiss = { ui.confirmReq = null }, onOk = {
                    val r = ui.confirmReq
                    ui.confirmReq = null
                    r?.onOk?.invoke()
                })
                ToastHost(ui.toastMsg, navBlock)

                AnimatedVisibility(!onboarded, enter = fadeIn(tween(200)), exit = fadeOut(tween(350)) + slideOutVertically(tween(400, easing = Emphasized)) { it / 6 }) {
                    Onboarding()
                }
            }
        }
    }
}

private fun tabRoot(t: Tab): Dest = when (t) {
    Tab.Home -> Dest.Home
    Tab.Plan -> Dest.Plan
    Tab.Focus -> Dest.Focus
    Tab.Syllabus -> Dest.Syllabus
    Tab.Tests -> Dest.Tests
}

@Composable
private fun ScreenFor(d: Dest) {
    when (d) {
        Dest.Home -> HomeScreen()
        Dest.Plan -> PlanScreen()
        Dest.Focus -> FocusScreen()
        Dest.Syllabus -> SyllabusScreen()
        Dest.Tests -> TestsScreen()
        Dest.Analysis -> AnalysisScreen()
        Dest.Notebook -> NotebookScreen()
        is Dest.Subject -> SubjectScreen(d.id)
        is Dest.Test -> TestDetailScreen(d.id)
        Dest.Stats -> StatsScreen()
        Dest.Habits -> HabitsScreen()
        Dest.Timetable -> TimetableScreen()
        Dest.Badges -> BadgesScreen()
        Dest.Settings -> SettingsScreen()
        Dest.Look -> LookScreen()
    }
}

private fun fabFor(ui: Ui, snap: Snap): (() -> Unit)? = when (val d = ui.top) {
    Dest.Plan -> ({ ui.open(Sheet.TaskForm(null, null)) })
    Dest.Syllabus -> ({ ui.open(Sheet.SubjectForm(null)) })
    is Dest.Subject -> if (snap.subOrNull(d.id) != null) ({ ui.open(Sheet.TopicAdd(d.id)) }) else null
    Dest.Tests -> ({ ui.open(Sheet.TestForm(null)) })
    is Dest.Test -> ({ ui.open(Sheet.MistakeForm(null, d.id)) })
    Dest.Notebook -> ({ ui.open(Sheet.MistakeForm(null, null)) })
    Dest.Habits -> ({ ui.open(Sheet.HabitForm(null)) })
    Dest.Timetable -> ({ ui.open(Sheet.BlockForm(null, ui.ttDay)) })
    else -> null
}

@Composable
private fun MiniTimer(store: Store, ui: Ui) {
    val c = Th.c
    val state by store.state.collectAsState()
    val now by store.now.collectAsState()
    val t = state.timer ?: return
    val e = tElapsed(t, now)
    val txt = if (t.planned > 0) clock(t.planned - e, true) else clock(e, false)
    val subj = state.subjects.firstOrNull { it.id == t.sid }
    Row(
        Modifier.shadow(10.dp, RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(c.surface)
            .pressable(scaleTo = 0.94f) { ui.tick(); ui.tab(Dest.Focus) }.padding(start = 14.dp, end = 18.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(if (t.phase != "focus") c.ok else if (t.running) c.acc else c.sub))
        Box(Modifier.width(10.dp))
        Tx(txt, size = 17.sp, weight = FontWeight.Bold, maxLines = 1)
        Box(Modifier.width(8.dp))
        Tx(if (t.phase != "focus") "☕" else subj?.emoji ?: "🎯", size = 15.sp)
    }
}
