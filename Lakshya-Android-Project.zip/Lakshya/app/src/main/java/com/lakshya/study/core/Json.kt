package com.lakshya.study.core

/**
 * Tiny dependency-free JSON reader / writer.
 * Objects -> LinkedHashMap<String, Any?>, arrays -> ArrayList<Any?>,
 * integers -> Long, other numbers -> Double.
 * Keeping this in plain Kotlin means the whole data layer can be unit-tested on a JVM.
 */
object Json {

    fun parse(text: String): Any? {
        val p = Parser(text.removePrefix("﻿"))
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != p.s.length) throw IllegalArgumentException("Trailing data at ${p.i}")
        return v
    }

    fun write(v: Any?): String {
        val sb = StringBuilder()
        w(sb, v)
        return sb.toString()
    }

    // ------------------------------------------------------------------ writer
    private fun w(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (v) "true" else "false")
            is String -> quote(sb, v)
            is Int -> sb.append(v)
            is Long -> sb.append(v)
            is Double -> sb.append(numStr(v))
            is Float -> sb.append(numStr(v.toDouble()))
            is Number -> sb.append(numStr(v.toDouble()))
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k.toString())
                    sb.append(':')
                    w(sb, value)
                }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (value in v) {
                    if (!first) sb.append(',')
                    first = false
                    w(sb, value)
                }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun numStr(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "0"
        return if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') {
                    sb.append("\\u").append(c.code.toString(16).padStart(4, '0'))
                } else sb.append(c)
            }
        }
        sb.append('"')
    }

    // ------------------------------------------------------------------ parser
    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun err(m: String): Nothing = throw IllegalArgumentException("$m at $i")

        fun value(): Any? {
            if (i >= s.length) err("Unexpected end")
            val c = s[i]
            return when {
                c == '{' -> obj()
                c == '[' -> arr()
                c == '"' -> str()
                c == 't' -> lit("true", true)
                c == 'f' -> lit("false", false)
                c == 'n' -> lit("null", null)
                c == '-' || c.isDigit() -> num()
                else -> err("Unexpected '$c'")
            }
        }

        fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) err("Bad literal")
            i += word.length
            return v
        }

        fun obj(): Map<String, Any?> {
            i++ // {
            val m = LinkedHashMap<String, Any?>()
            ws()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') err("Expected key")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') err("Expected ':'")
                i++
                ws()
                m[k] = value()
                ws()
                if (i >= s.length) err("Unterminated object")
                if (s[i] == ',') { i++; continue }
                if (s[i] == '}') { i++; return m }
                err("Expected ',' or '}'")
            }
        }

        fun arr(): List<Any?> {
            i++ // [
            val l = ArrayList<Any?>()
            ws()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                ws()
                l.add(value())
                ws()
                if (i >= s.length) err("Unterminated array")
                if (s[i] == ',') { i++; continue }
                if (s[i] == ']') { i++; return l }
                err("Expected ',' or ']'")
            }
        }

        fun str(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) err("Unterminated string")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) err("Bad escape")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) err("Bad unicode escape")
                                sb.append(s.substring(i, i + 4).toInt(16).toChar())
                                i += 4
                            }
                            else -> err("Bad escape '$e'")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun num(): Any {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '-' || s[i] == '+' || s[i] == '.' || s[i] == 'e' || s[i] == 'E')) i++
            val t = s.substring(st, i)
            val isFloat = t.contains('.') || t.contains('e') || t.contains('E')
            if (!isFloat) {
                val l = t.toLongOrNull()
                if (l != null) return l
            }
            return t.toDoubleOrNull() ?: err("Bad number '$t'")
        }
    }
}
