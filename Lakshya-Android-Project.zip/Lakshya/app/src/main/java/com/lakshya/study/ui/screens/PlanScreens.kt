package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.DOW
import com.lakshya.study.core.HABIT_SUG
import com.lakshya.study.core.addDays
import com.lakshya.study.core.carryOver
import com.lakshya.study.core.dayDiff
import com.lakshya.study.core.dowOf
import com.lakshya.study.core.dropOld
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.smartPlan
import com.lakshya.study.core.saveHabit
import com.lakshya.study.core.toMin
import com.lakshya.study.core.to12
import com.lakshya.study.core.toggleHabitDay
import com.lakshya.study.core.toggleTask
import com.lakshya.study.core.weekStart
import com.lakshya.study.core.dayOfMonth
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Badge
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.CheckCircle
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipFlow
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.EmojiBubble
import com.lakshya.study.ui.components.EmptyCard
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.Icon
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ItemRow
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.components.pressable
import com.lakshya.study.ui.theme.Th

// ============================================================================ PLAN
@Composable
fun PlanScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val date = ui.planDate.ifEmpty { snap.today }
    val tasks = snap.tasksOn(date)
    val done = tasks.count { it.done }
    val mins = tasks.sumOf { it.est }
    val ws = weekStart(date)
    val overdue = s.tasks.count { it.date < snap.today && !it.done }

    Screen(
        title = "Planner",
        subtitle = if (date == snap.today) "Aaj · ${fmtD(date)}" else fmtD(date),
        actions = { IconBtn(Ic.Table, { ui.go(Dest.Timetable) }, bg = c.surface) }
    ) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Ic.Back, { ui.planDate = addDays(date, -7) }, size = 34.dp)
                    Tx(fmtD(ws) + " – " + fmtD(addDays(ws, 6)), Modifier.weight(1f), size = 13.5.sp, weight = FontWeight.SemiBold, align = TextAlign.Center)
                    IconBtn(Ic.Next, { ui.planDate = addDays(date, 7) }, size = 34.dp)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 0..6) {
                        val d = addDays(ws, i)
                        DayCell(DOW[i], dayOfMonth(d).toString(), d == date, d == snap.today, s.tasks.any { it.date == d }, Modifier.weight(1f)) {
                            ui.tick(); ui.planDate = if (d == snap.today) "" else d
                        }
                    }
                }
                if (date != snap.today) {
                    Spacer(Modifier.height(8.dp))
                    Btn("Aaj par jao", { ui.planDate = "" }, Modifier.fillMaxWidth(), kind = BtnKind.Soft)
                }
            }
        }

        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx("$done / ${tasks.size} complete", size = 16.sp, weight = FontWeight.Bold)
                        Tx("Planned: ${mins / 60}h ${mins % 60}m", size = 12.5.sp, color = c.sub)
                    }
                    Btn("Smart Plan", {
                        val plan = smartPlan(snap, date, System.currentTimeMillis())
                        if (plan.isEmpty()) ui.toast("Plan me abhi kuch add karne layak nahi mila")
                        else { store.commit { st -> st.copy(tasks = st.tasks + plan) }; ui.toast("${plan.size} tasks add hue ✨", "ok") }
                    }, icon = Ic.Wand, kind = BtnKind.Soft)
                }
                if (tasks.isNotEmpty()) { Spacer(Modifier.height(10.dp)); ProgressBar(done.toFloat() / tasks.size, c.acc) }
            }
        }

        if (overdue > 0 && date == snap.today) item {
            AppCard(container = c.warn.copy(alpha = 0.14f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx("⏰", size = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Tx("$overdue pichle tasks adhure hain", Modifier.weight(1f), size = 14.sp, weight = FontWeight.SemiBold, color = c.warn)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Aaj le aao", { store.commit { it.carryOver(snap.today) }; ui.toast("Aaj me shift kiye", "ok") }, kind = BtnKind.Soft)
                    Btn("Hata do", { store.commit { it.dropOld(snap.today) } }, kind = BtnKind.Ghost)
                }
            }
        }

        if (tasks.isEmpty()) item {
            EmptyCard("🗓", "Is din ka plan khaali hai", "Task add karo ya Smart Plan se auto-plan banwao.") {
                Btn("Task add karo", { ui.open(Sheet.TaskForm(null, date)) })
            }
        } else item {
            AppCard {
                tasks.forEachIndexed { i, t ->
                    val sb = snap.subOrNull(t.sid)
                    ItemRow(
                        t.title,
                        sub = listOfNotNull(sb?.name, snap.topic(t.tid)?.name, "${t.est}m", if (t.time.isNotEmpty()) to12(t.time) else null).joinToString(" · "),
                        done = t.done, onClick = { ui.open(Sheet.TaskForm(t.id, null)) },
                        leading = { CheckCircle(t.done) { ui.tick(); store.commit { st -> st.toggleTask(t.id, System.currentTimeMillis(), snap.today) } } },
                        trailing = {
                            if (!t.done) IconBtn(Ic.Play, { ui.focusOn(t.sid, t.tid) }, tint = c.accText, bg = c.accSoft, size = 36.dp)
                        }
                    )
                    if (i < tasks.size - 1) Divider()
                }
            }
        }
    }
}

@Composable
private fun DayCell(dow: String, day: String, selected: Boolean, today: Boolean, has: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = Th.c
    Column(
        modifier.clip(RoundedCornerShape(Th.d.inner)).background(if (selected) c.acc else androidx.compose.ui.graphics.Color.Transparent)
            .pressable(scaleTo = 0.92f, onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Tx(dow, size = 11.sp, color = if (selected) c.onAcc.copy(alpha = 0.8f) else c.sub, maxLines = 1)
        Tx(day, Modifier.padding(vertical = 2.dp), size = 16.sp, weight = FontWeight.Bold, color = if (selected) c.onAcc else if (today) c.accText else c.text, maxLines = 1)
        Box(Modifier.size(5.dp).clip(CircleShape).background(if (has) (if (selected) c.onAcc else c.acc) else androidx.compose.ui.graphics.Color.Transparent))
    }
}

// ============================================================================ TIMETABLE
@Composable
fun TimetableScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val todayDow = dowOf(snap.today)
    val day = ui.ttDay
    val list = remember(snap.s.blocks, day) { snap.s.blocks.filter { it.days.contains(day) }.sortedBy { toMin(it.start) } }
    val totalMin = list.sumOf { toMin(it.end) - toMin(it.start) }

    Screen("Timetable", onBack = { ui.back() }, subtitle = "Weekly study slots") {
        item {
            Segmented(DOW.mapIndexed { i, d -> i.toString() to d }, day.toString(), { ui.tick(); ui.ttDay = it.toInt() })
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Tx(com.lakshya.study.core.DOW_LONG[day] + if (day == todayDow) " · Aaj" else "", Modifier.weight(1f), size = 15.sp, weight = FontWeight.SemiBold)
                Tx("${totalMin / 60}h ${totalMin % 60}m", size = 13.sp, color = c.sub)
            }
        }
        if (list.isEmpty()) item {
            EmptyCard("🕘", "Is din koi slot nahi", "Fixed study slots banao. Clash ho to app bata dega.") {
                Btn("Slot add karo", { ui.open(Sheet.BlockForm(null, day)) })
            }
        } else items(list, key = { it.id }) { b ->
            val sb = snap.sub(b.sid)
            AppCard(onClick = { ui.open(Sheet.BlockForm(b.id, day)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EmojiBubble(sb.emoji, colorOf(sb.color))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(b.label.ifEmpty { sb.name }, size = 15.5.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx("${to12(b.start)} – ${to12(b.end)}", size = 13.sp, color = c.sub)
                    }
                    if (b.days.size > 1) Badge(b.days.sorted().joinToString(" ") { DOW[it].take(2) }, c.sub)
                }
            }
        }
    }
}

// ============================================================================ HABITS
@Composable
fun HabitsScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val days = remember(snap.today) { (6 downTo 0).map { addDays(snap.today, -it) } }

    Screen("Habits", onBack = { ui.back() }, subtitle = "Chhoti aadatein, bada asar") {
        if (s.habits.isEmpty()) {
            item {
                EmptyCard("🌱", "Koi habit nahi", "Ek chhoti si aadat se shuru karo.") {
                    Btn("Habit banao", { ui.open(Sheet.HabitForm(null)) })
                }
            }
            item { SectionTitle("Suggestions") }
            item {
                ChipFlow {
                    HABIT_SUG.forEach { (e, n) ->
                        Chip("$e $n", false, { store.commit { it.saveHabit(null, e, n, System.currentTimeMillis()) } })
                    }
                }
            }
        } else items(s.habits, key = { it.id }) { h ->
            val st = snap.habitStreak(h)
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.pressable(scaleTo = 0.98f) { ui.open(Sheet.HabitForm(h.id)) }) {
                    EmojiBubble(h.emoji, c.acc)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(h.name, size = 15.5.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx("🔥 ${st.cur} din · best ${st.best}", size = 12.sp, color = c.sub)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    days.forEach { d ->
                        val on = h.days.contains(d)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Tx(DOW[dowOf(d)].take(1), size = 11.sp, color = c.sub)
                            Spacer(Modifier.height(4.dp))
                            CheckCircle(on) { ui.tick(); store.commit { it.toggleHabitDay(h.id, d) } }
                        }
                    }
                }
            }
        }
    }
}
