package com.lakshya.study.core

/* Pure state mutations used by the UI. Every function returns a new AppState. */

fun AppState.setTopic(id: String, f: (Topic) -> Topic): AppState =
    copy(topics = topics.map { if (it.id == id) f(it) else it })

fun AppState.cycleTopicStatus(id: String, today: String): AppState = setTopic(id) { t ->
    t.withStatus(when (t.status) { Status.TODO -> Status.LEARNING; Status.LEARNING -> Status.DONE; else -> Status.TODO }, today)
}

fun AppState.reviseTopic(id: String, today: String): AppState {
    if (topics.none { it.id == id }) return this
    return setTopic(id) { it.markRevised(today) }.bumpRev(today)
}

fun AppState.saveTopic(id: String, name: String, status: String, conf: Int, imp: Boolean, notes: String, today: String): AppState =
    setTopic(id) { t -> t.copy(name = name, conf = conf, imp = imp, notes = notes).withStatus(status, today) }

fun AppState.deleteTopic(id: String): AppState = copy(
    topics = topics.filter { it.id != id },
    tasks = tasks.map { if (it.tid == id) it.copy(tid = "") else it },
    sessions = sessions.map { if (it.tid == id) it.copy(tid = "") else it }
)

/** One topic per line; trailing * marks it important. Returns new state and number added. */
fun AppState.addTopics(sid: String, text: String): Pair<AppState, Int> {
    val lines = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    val list = ArrayList(topics)
    var n = 0
    for (l in lines) {
        val imp = l.endsWith("*")
        val name = (if (imp) l.dropLast(1) else l).trim()
        if (name.isNotEmpty() && list.none { it.sid == sid && it.name.equals(name, ignoreCase = true) }) {
            list.add(mkTopic(sid, name, imp)); n++
        }
    }
    return copy(topics = list) to n
}

fun AppState.ensureTopic(sid: String, name: String): Pair<AppState, Topic> {
    val ex = topics.firstOrNull { it.sid == sid && it.name.equals(name, ignoreCase = true) }
    if (ex != null) return this to ex
    val t = mkTopic(sid, name)
    return copy(topics = topics + t) to t
}

fun AppState.loadPreset(): AppState {
    val pr = buildPreset()
    val subs = subjects + pr.subjects.filter { p -> subjects.none { it.id == p.id } }
    val tops = topics + pr.topics.filter { p -> topics.none { it.sid == p.sid && it.name == p.name } }
    return copy(subjects = subs, topics = tops)
}

// ------------------------------------------------------------------ subjects
fun AppState.saveSubject(id: String?, name: String, short: String, emoji: String, color: String, merit: Boolean): AppState {
    val sh = short.ifBlank { name.take(10) }
    return if (id != null && subjects.any { it.id == id })
        copy(subjects = subjects.map { if (it.id == id) it.copy(name = name, short = sh, emoji = emoji, color = color, merit = merit) else it })
    else copy(subjects = subjects + Subject(uid(), name, sh, emoji, color, merit, false))
}

fun AppState.toggleArchive(id: String): AppState =
    copy(subjects = subjects.map { if (it.id == id) it.copy(archived = !it.archived) else it })

fun AppState.deleteSubject(id: String): AppState {
    val tests2 = tests.map { t -> t.copy(sections = t.sections.filterKeys { it != id }) }.filter { it.sections.isNotEmpty() }
    return copy(
        subjects = subjects.filter { it.id != id }, topics = topics.filter { it.sid != id },
        mistakes = mistakes.filter { it.sid != id }, tasks = tasks.filter { it.sid != id }, blocks = blocks.filter { it.sid != id },
        sessions = sessions.map { if (it.sid == id) it.copy(sid = "", tid = "") else it }, tests = tests2
    )
}

// ------------------------------------------------------------------ tasks / blocks / habits
fun AppState.toggleTask(id: String, now: Long, today: String): AppState {
    val t = tasks.firstOrNull { it.id == id } ?: return this
    val done = !t.done
    var s = copy(tasks = tasks.map { if (it.id == id) it.copy(done = done, doneAt = if (done) now else 0L) else it })
    if (done && t.kind != "rev") {
        val tp = topics.firstOrNull { it.id == t.tid }
        if (tp != null && tp.status == Status.TODO) s = s.setTopic(tp.id) { it.withStatus(Status.LEARNING, today) }
    }
    return s
}

fun AppState.saveTask(id: String?, date: String, title: String, sid: String, tid: String, est: Int, time: String, now: Long): AppState =
    if (id != null && tasks.any { it.id == id })
        copy(tasks = tasks.map { if (it.id == id) it.copy(title = title, date = date, time = time, sid = sid, tid = tid, est = est) else it })
    else copy(tasks = tasks + Task(uid(), date, title, sid, tid, est, time, false, now))

fun AppState.deleteTask(id: String): AppState = copy(tasks = tasks.filter { it.id != id })
fun AppState.carryOver(today: String): AppState = copy(tasks = tasks.map { if (it.date < today && !it.done) it.copy(date = today) else it })
fun AppState.dropOld(today: String): AppState = copy(tasks = tasks.filter { it.date >= today || it.done })

/** Returns (state, errorMessage). */
fun AppState.saveBlock(id: String?, days: List<Int>, sid: String, start: String, end: String, label: String, subName: (String) -> String): Pair<AppState, String?> {
    if (sid.isEmpty()) return this to "Subject chuno"
    if (start.isEmpty() || end.isEmpty() || toMin(end) <= toMin(start)) return this to "End time start ke baad hona chahiye"
    val clash = blocks.firstOrNull { b ->
        b.id != id && b.days.any { days.contains(it) } && toMin(b.start) < toMin(end) && toMin(start) < toMin(b.end)
    }
    if (clash != null) return this to "Ye slot \"${clash.label.ifEmpty { subName(clash.sid) }}\" (${to12(clash.start)}–${to12(clash.end)}) se takra raha hai"
    val d = days.sorted()
    return if (id != null && blocks.any { it.id == id })
        copy(blocks = blocks.map { if (it.id == id) it.copy(days = d, sid = sid, start = start, end = end, label = label) else it }) to null
    else copy(blocks = blocks + Block(uid(), d, start, end, sid, label)) to null
}

fun AppState.deleteBlock(id: String): AppState = copy(blocks = blocks.filter { it.id != id })

fun AppState.toggleHabitDay(id: String, date: String): AppState =
    copy(habits = habits.map { h -> if (h.id == id) h.copy(days = if (h.days.contains(date)) h.days - date else h.days + date) else h })

fun AppState.saveHabit(id: String?, emoji: String, name: String, now: Long): AppState =
    if (id != null && habits.any { it.id == id }) copy(habits = habits.map { if (it.id == id) it.copy(emoji = emoji, name = name) else it })
    else copy(habits = habits + Habit(uid(), emoji, name, emptySet(), now))

fun AppState.deleteHabit(id: String): AppState = copy(habits = habits.filter { it.id != id })

// ------------------------------------------------------------------ sessions
fun AppState.addManualSession(date: String, mins: Int, sid: String, tid: String): AppState =
    copy(sessions = sessions + Session(uid(), date, noonOf(date), mins * 60, sid, tid, "manual", 0, true))

fun AppState.deleteSession(id: String): AppState = copy(sessions = sessions.filter { it.id != id })

// ------------------------------------------------------------------ tests / mistakes
/** Returns (state, testId). */
fun AppState.saveTest(id: String?, name: String, date: String, mins: Int, type: String, sections: Map<String, Section>, now: Long): Pair<AppState, String> =
    if (id != null && tests.any { it.id == id })
        copy(tests = tests.map { if (it.id == id) it.copy(name = name, date = date, mins = mins, type = type, sections = sections) else it }) to id
    else {
        val nid = uid()
        copy(tests = tests + TestRec(nid, name, date, type, mins, now, sections)) to nid
    }

fun AppState.deleteTest(id: String): AppState = copy(tests = tests.filter { it.id != id }, mistakes = mistakes.filter { it.testId != id })

fun AppState.addMistakes(
    testId: String, sid: String, tid: String, kind: String, reason: String, q: String, ans: String, qty: Int, now: Long, today: String
): AppState {
    val tn = topics.firstOrNull { it.id == tid }?.name ?: ""
    val list = (0 until qty).map { i ->
        Mistake(uid() + i, testId, sid, tid, tn, kind, reason, if (i == 0) q else "", if (i == 0) ans else "", now + i, 0, today, false)
    }
    return copy(mistakes = mistakes + list)
}

fun AppState.updateMistake(id: String, sid: String, kind: String, tid: String, reason: String, q: String, ans: String): AppState {
    val tn = topics.firstOrNull { it.id == tid }?.name ?: ""
    return copy(mistakes = mistakes.map { if (it.id == id) it.copy(sid = sid, kind = kind, tid = tid, tn = tn, reason = reason, q = q, ans = ans) else it })
}

fun AppState.deleteMistake(id: String): AppState = copy(mistakes = mistakes.filter { it.id != id })

fun AppState.toggleMistakeDone(id: String, today: String): AppState {
    val m = mistakes.firstOrNull { it.id == id } ?: return this
    val nm = if (m.done) m.copy(done = false, box = 0, due = today) else m.copy(done = true, box = 5, due = "")
    val s = copy(mistakes = mistakes.map { if (it.id == id) nm else it })
    return if (!m.done) s.bumpRev(today) else s
}

/** Flashcard answer: grade = good | hard | again. */
fun AppState.answerCard(id: String, grade: String, today: String): AppState {
    val m = mistakes.firstOrNull { it.id == id } ?: return this
    val nm = when (grade) { "good" -> m.srGood(today); "hard" -> m.srHard(today); else -> m.srAgain(today) }
    return copy(mistakes = mistakes.map { if (it.id == id) nm else it }).bumpRev(today)
}
