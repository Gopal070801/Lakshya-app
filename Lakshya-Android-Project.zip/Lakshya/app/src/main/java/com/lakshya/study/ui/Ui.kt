package com.lakshya.study.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lakshya.study.core.Snap
import com.lakshya.study.data.Store
import com.lakshya.study.ui.components.Ic

enum class Tab(val label: String, val ic: Ic) {
    Home("Home", Ic.Home), Plan("Plan", Ic.Plan), Focus("Focus", Ic.Focus), Syllabus("Syllabus", Ic.Syl), Tests("Tests", Ic.Test)
}

sealed class Dest(val tab: Tab) {
    object Home : Dest(Tab.Home)
    object Plan : Dest(Tab.Plan)
    object Focus : Dest(Tab.Focus)
    object Syllabus : Dest(Tab.Syllabus)
    object Tests : Dest(Tab.Tests)
    object Analysis : Dest(Tab.Tests)
    object Notebook : Dest(Tab.Tests)
    data class Subject(val id: String) : Dest(Tab.Syllabus)
    data class Test(val id: String) : Dest(Tab.Tests)
    object Stats : Dest(Tab.Home)
    object Habits : Dest(Tab.Home)
    object Timetable : Dest(Tab.Plan)
    object Badges : Dest(Tab.Home)
    object Settings : Dest(Tab.Home)
    object Look : Dest(Tab.Home)
}

sealed class Sheet {
    data class TaskForm(val id: String?, val date: String?) : Sheet()
    data class SubjectForm(val id: String?) : Sheet()
    data class TopicEdit(val id: String) : Sheet()
    data class TopicAdd(val sid: String) : Sheet()
    data class TestForm(val id: String?) : Sheet()
    data class MistakeForm(val id: String?, val testId: String?) : Sheet()
    data class BlockForm(val id: String?, val day: Int) : Sheet()
    data class HabitForm(val id: String?) : Sheet()
    object Manual : Sheet()
    object Menu : Sheet()
    object RevHub : Sheet()
}

class ConfirmReq(val title: String, val msg: String, val ok: String, val danger: Boolean, val onOk: () -> Unit)
class ToastMsg(val id: Long, val msg: String, val type: String)

/** Filters kept while navigating (mirrors the web app's UI state object). */
class NbFilter(
    val status: String = "due", val sid: String = "all", val reason: String = "all", val tid: String = "", val q: String = ""
)

@Stable
class Ui(val store: Store) {
    var stack by mutableStateOf<List<Dest>>(listOf(Dest.Home))
    var sheet by mutableStateOf<Sheet?>(null)
    var confirmReq by mutableStateOf<ConfirmReq?>(null)
    var revise by mutableStateOf<List<String>?>(null)
    var toastMsg by mutableStateOf<ToastMsg?>(null)

    // cross-screen UI state
    var planDate by mutableStateOf("")            // "" = today
    var ttDay by mutableStateOf(0)
    var focusSid by mutableStateOf("")
    var focusTid by mutableStateOf("")
    var focusFree by mutableStateOf(false)
    var nb by mutableStateOf(NbFilter())
    var anSec by mutableStateOf("merit")
    var anRange by mutableStateOf("5")
    var statsRange by mutableStateOf("week")
    var testsType by mutableStateOf("all")

    var haptic: HapticFeedback? = null
    var askNotif: () -> Unit = {}
    var hapticsOn: Boolean = true

    private var toastSeq = 0L

    val top: Dest get() = stack.last()

    val hasOverlay: Boolean get() = confirmReq != null || sheet != null || revise != null

    fun tab(d: Dest) { stack = listOf(d) }
    fun go(d: Dest) { if (top != d) stack = stack + d }

    /** Handles Android's back button. Returns false when nothing is left to go back to. */
    fun back(): Boolean {
        if (confirmReq != null) { confirmReq = null; return true }
        if (sheet != null) { sheet = null; return true }
        if (revise != null) { revise = null; return true }
        if (stack.size > 1) { stack = stack.dropLast(1); return true }
        if (top != Dest.Home) { stack = listOf(Dest.Home); return true }
        return false
    }

    fun open(s: Sheet) { sheet = s }
    fun closeSheet() { sheet = null }

    fun confirm(title: String, msg: String, ok: String, danger: Boolean = true, onOk: () -> Unit) {
        confirmReq = ConfirmReq(title, msg, ok, danger, onOk)
    }

    fun toast(msg: String, type: String = "") { toastMsg = ToastMsg(++toastSeq, msg, type) }

    fun tick() { if (hapticsOn) haptic?.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    fun strongHaptic() { if (hapticsOn) haptic?.performHapticFeedback(HapticFeedbackType.LongPress) }

    fun startRevise(ids: List<String>) {
        if (ids.isEmpty()) { toast("Revise karne ke liye kuch nahi bacha 🎉", "ok"); return }
        revise = ids
    }

    fun focusOn(sid: String, tid: String) {
        if (sid.isNotEmpty()) focusSid = sid
        focusTid = tid
        focusFree = false
        tab(Dest.Focus)
    }

    fun openNotebookFor(tid: String, sid: String = "all") {
        nb = NbFilter(status = "all", sid = sid, tid = tid)
        tab(Dest.Notebook)
    }
}

val LocalSnap = compositionLocalOf<Snap> { error("Snap not provided") }
val LocalUi = compositionLocalOf<Ui> { error("Ui not provided") }
val LocalStore = compositionLocalOf<Store> { error("Store not provided") }
val LocalBottomPad = compositionLocalOf { 90.dp }

@Composable
fun rememberBottomPadDefault(): Dp = 90.dp
