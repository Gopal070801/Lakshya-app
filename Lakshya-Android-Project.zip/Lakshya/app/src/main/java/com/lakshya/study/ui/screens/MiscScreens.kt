package com.lakshya.study.ui.screens

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.ACCENTS
import com.lakshya.study.core.AppState
import com.lakshya.study.core.BADGES
import com.lakshya.study.core.DOW
import com.lakshya.study.core.Pomo
import com.lakshya.study.core.Settings
import com.lakshya.study.core.THEMES
import com.lakshya.study.core.addDays
import com.lakshya.study.core.dayDiff
import com.lakshya.study.core.dayOfMonth
import com.lakshya.study.core.dowOf
import com.lakshya.study.core.f1
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.fmtDur
import com.lakshya.study.core.fmtHrs
import com.lakshya.study.core.hourOf
import com.lakshya.study.core.isValidDate
import com.lakshya.study.core.loadDemo
import com.lakshya.study.core.removeDemo
import com.lakshya.study.core.weekStart
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.BarChart
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.ChipFlow
import com.lakshya.study.ui.components.DateField
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.Donut
import com.lakshya.study.ui.components.DonutItem
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Heatmap
import com.lakshya.study.ui.components.Label
import com.lakshya.study.ui.components.OneSwitch
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.SettingRow
import com.lakshya.study.ui.components.Stepper
import com.lakshya.study.ui.components.Swatch
import com.lakshya.study.ui.components.TimeField
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.components.pressable
import com.lakshya.study.ui.theme.Th

// ============================================================================ STATS
@Composable
fun StatsScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val s = snap.s
    val goal = s.profile.dailyGoal.coerceAtLeast(1)
    val days = when (ui.statsRange) { "week" -> 7; "month" -> 30; else -> 90 }
    val dates = remember(snap.today, days) { (days - 1 downTo 0).map { addDays(snap.today, -it) } }
    val mins = dates.map { snap.dayMins(it) }
    val rangeSecs = mins.sum() * 60
    val dateSet = dates.toSet()
    val sess = s.sessions.filter { it.date in dateSet }

    Screen("Stats", onBack = { ui.back() }, subtitle = "Padhai ka hisaab") {
        item { Segmented(listOf("week" to "7 din", "month" to "30 din", "q" to "90 din"), ui.statsRange, { ui.statsRange = it }) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(fmtDur(rangeSecs), "Total", Modifier.weight(1f))
                StatTile(fmtDur(rangeSecs / days), "Avg / din", Modifier.weight(1f))
                StatTile("${mins.count { it >= s.profile.streakMin }}", "Goal din", Modifier.weight(1f), color = c.ok)
                StatTile("${sess.size}", "Sessions", Modifier.weight(1f))
            }
        }
        item {
            AppCard {
                Tx("Roz ka time (min)", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                Spacer(Modifier.height(10.dp))
                if (days <= 30) {
                    BarChart(
                        mins.map { it.toFloat() },
                        dates.map { if (days == 7) DOW[dowOf(it)] else dayOfMonth(it).toString() },
                        goal = goal.toFloat(), highlight = dates.lastIndex
                    )
                } else {
                    val weeks = mins.chunked(7)
                    BarChart(weeks.map { it.sum().toFloat() }, weeks.indices.map { "W${it + 1}" }, highlight = weeks.lastIndex)
                }
            }
        }
        val bySub = sess.groupBy { it.sid }.mapValues { e -> e.value.sumOf { it.secs } }.entries.sortedByDescending { it.value }
        if (bySub.isNotEmpty()) item {
            AppCard {
                Tx("Subject-wise", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Donut(bySub.map { DonutItem(it.value.toFloat(), colorOf(snap.sub(it.key).color)) }, size = 116.dp, centerTop = fmtDur(rangeSecs), centerSub = "total")
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bySub.take(6).forEach { (sid, v) ->
                            val sb = snap.sub(sid)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(colorOf(sb.color)))
                                Spacer(Modifier.width(8.dp))
                                Tx(sb.short.ifEmpty { sb.name }, Modifier.weight(1f), size = 12.5.sp, maxLines = 1)
                                Tx(fmtDur(v), size = 12.sp, color = c.sub)
                            }
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                Tx("Din ka kaunsa time best?", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                Spacer(Modifier.height(10.dp))
                val real = s.sessions.filter { !it.manual }
                fun bucket(h: Int) = when { h in 5..11 -> 0; h in 12..16 -> 1; h in 17..20 -> 2; else -> 3 }
                val v = FloatArray(4)
                real.forEach { v[bucket(hourOf(it.ts))] += it.secs / 60f }
                BarChart(v.toList(), listOf("Subah", "Dopahar", "Shaam", "Raat"), height = 100.dp)
            }
        }
        item {
            AppCard {
                Tx("Pichle 16 hafte", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                Spacer(Modifier.height(10.dp))
                val ws = addDays(weekStart(snap.today), -15 * 7)
                val cells = (0 until 16 * 7).map { i ->
                    val w = i / 7; val dd = i % 7
                    val d = addDays(ws, w * 7 + dd)
                    if (d > snap.today) null else snap.dayMins(d).toFloat() / goal
                }
                Heatmap(cells, 16)
            }
        }
        item { SectionTitle("Records") }
        item {
            val best = snap.dayMap.entries.maxByOrNull { it.value }
            val longest = s.sessions.maxByOrNull { it.secs }
            AppCard {
                RecordRow("🔥 Current streak", "${snap.streak.cur} din")
                Divider()
                RecordRow("🏔 Best streak", "${snap.streak.best} din")
                Divider()
                RecordRow("📅 Best din", if (best != null) fmtDur(best.value) + " · " + fmtD(best.key) else "-")
                Divider()
                RecordRow("⏱ Sabse lamba session", if (longest != null) fmtDur(longest.secs) else "-")
                Divider()
                RecordRow("📚 Total padhai", fmtHrs(snap.totalSecs))
                Divider()
                RecordRow("🎯 Avg session", if (s.sessions.isNotEmpty()) fmtDur(snap.totalSecs / s.sessions.size) else "-")
            }
        }
    }
}

@Composable
private fun RecordRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Tx(k, Modifier.weight(1f), size = 14.5.sp)
        Tx(v, size = 14.5.sp, weight = FontWeight.Bold, color = Th.c.accText, maxLines = 1)
    }
}

// ============================================================================ BADGES
@Composable
fun BadgesScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val s = snap.s
    val lv = snap.level
    val got = BADGES.count { s.badges.containsKey(it.id) }

    Screen("Badges", onBack = { ui.back() }, subtitle = "$got / ${BADGES.size} unlocked") {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(Th.d.card)).background(c.grad).padding(20.dp)) {
                Column {
                    Tx("LEVEL ${lv.level}", size = 12.sp, weight = FontWeight.SemiBold, color = c.onAcc.copy(alpha = 0.8f))
                    Tx(lv.title, Modifier.padding(top = 2.dp), size = 26.sp, weight = FontWeight.Bold, color = c.onAcc)
                    Spacer(Modifier.height(12.dp))
                    ProgressBar(lv.p.toFloat().coerceIn(0f, 1f), c.onAcc, height = 10.dp)
                    Tx("${lv.xp} / ${lv.hi} XP", Modifier.padding(top = 6.dp), size = 12.5.sp, color = c.onAcc.copy(alpha = 0.85f))
                }
            }
        }
        items(BADGES, key = { it.id }) { b ->
            val unlocked = s.badges.containsKey(b.id)
            val (cur, max) = b.progress(snap)
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(if (unlocked) c.accSoft else c.surface2),
                        contentAlignment = Alignment.Center
                    ) { Tx(if (unlocked) b.emoji else "🔒", size = 24.sp, overflow = androidx.compose.ui.text.style.TextOverflow.Clip, color = if (unlocked) c.text else c.sub) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(b.name, size = 15.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx(b.desc, size = 12.5.sp, color = c.sub, maxLines = 2)
                        if (!unlocked) {
                            Spacer(Modifier.height(8.dp))
                            ProgressBar((cur / max).toFloat().coerceIn(0f, 1f), c.acc)
                        } else {
                            val dt = s.badges[b.id] ?: ""
                            if (isValidDate(dt)) Tx("Unlocked " + fmtD(dt), Modifier.padding(top = 4.dp), size = 11.5.sp, color = c.ok)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================ SETTINGS
private fun upd(store: com.lakshya.study.data.Store, f: (Settings) -> Settings) = store.commit { it.copy(settings = f(it.settings)) }

@Composable
fun SettingsScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val ctx = LocalContext.current
    val c = Th.c
    val s = snap.s
    val st = s.settings
    val p = s.profile

    var name by remember(p.name) { mutableStateOf(p.name) }
    var exam by remember(p.exam) { mutableStateOf(p.exam) }
    var date by remember(p.examDate) { mutableStateOf(p.examDate) }
    val dirty = name != p.name || exam != p.exam || date != p.examDate

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                store.flushNow()
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray(Charsets.UTF_8)) }
                true
            } catch (e: Throwable) { false }
            ui.toast(if (ok) "Backup save ho gaya ✅" else "Backup save nahi ho paya", if (ok) "ok" else "bad")
        }
    }
    val restore = rememberRestoreLauncher { ok -> ui.toast(if (ok) "Backup restore ho gaya ✅" else "Ye file valid backup nahi hai", if (ok) "ok" else "bad") }

    Screen("Settings", onBack = { ui.back() }) {
        // ---------------------------------------------------------------- profile
        item { SectionTitle("Profile") }
        item {
            AppCard {
                Label("Naam", Modifier.padding(top = 0.dp)); Field(name, { name = it }, hint = "Tumhara naam", maxLen = 30)
                Label("Exam"); Field(exam, { exam = it }, hint = "SSC MTS", maxLen = 40)
                Label("Exam date"); DateField(date, { date = it }, allowClear = true, placeholder = "Exam date chuno")
                if (dirty) {
                    Spacer(Modifier.height(12.dp))
                    Btn("Save", {
                        store.commit { it.copy(profile = it.profile.copy(name = name.trim(), exam = exam.trim().ifEmpty { "SSC MTS" }, examDate = date)) }
                        ui.toast("Profile save ho gayi", "ok")
                    }, Modifier.fillMaxWidth())
                }
                Divider(Modifier.padding(top = 12.dp))
                SettingRow("Roz ka goal", fmtDur(p.dailyGoal * 60)) {
                    Stepper({ store.commit { it.copy(profile = it.profile.copy(dailyGoal = (p.dailyGoal - 15).coerceAtLeast(15))) } },
                        { store.commit { it.copy(profile = it.profile.copy(dailyGoal = (p.dailyGoal + 15).coerceAtMost(960))) } })
                }
                SettingRow("Streak ke liye minimum", "${p.streakMin} min/din") {
                    Stepper({ store.commit { it.copy(profile = it.profile.copy(streakMin = (p.streakMin - 5).coerceAtLeast(5))) } },
                        { store.commit { it.copy(profile = it.profile.copy(streakMin = (p.streakMin + 5).coerceAtMost(240))) } })
                }
                SettingRow("Din kab badle", "Raat ${if (p.dayStart == 0) "12 baje" else "${p.dayStart} baje"} se naya din") {
                    Stepper({ store.commit { it.copy(profile = it.profile.copy(dayStart = (p.dayStart - 1).coerceAtLeast(0))) } },
                        { store.commit { it.copy(profile = it.profile.copy(dayStart = (p.dayStart + 1).coerceAtMost(6))) } })
                }
            }
        }

        // ---------------------------------------------------------------- look
        item { SectionTitle("Appearance") }
        item {
            AppCard(onClick = { ui.go(com.lakshya.study.ui.Dest.Look) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx("🎨", size = 24.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Tx("Theme & Look", size = 15.5.sp, weight = FontWeight.SemiBold)
                        Tx((if (st.ui == "coloros") "ColorOS" else "One UI") + " · " + com.lakshya.study.core.themeOf(st.theme).name, size = 12.5.sp, color = c.sub)
                    }
                    com.lakshya.study.ui.components.Icon(com.lakshya.study.ui.components.Ic.Next, c.sub, 18.dp)
                }
            }
        }

        // ---------------------------------------------------------------- pomodoro
        item { SectionTitle("Pomodoro") }
        item {
            val pm = st.pomo
            fun setP(f: (Pomo) -> Pomo) = upd(store) { it.copy(pomo = f(it.pomo)) }
            AppCard {
                SettingRow("Focus", "${pm.focus} min") { Stepper({ setP { it.copy(focus = (it.focus - 5).coerceAtLeast(5)) } }, { setP { it.copy(focus = (it.focus + 5).coerceAtMost(120)) } }) }
                SettingRow("Chhota break", "${pm.short} min") { Stepper({ setP { it.copy(short = (it.short - 1).coerceAtLeast(1)) } }, { setP { it.copy(short = (it.short + 1).coerceAtMost(30)) } }) }
                SettingRow("Lamba break", "${pm.long} min") { Stepper({ setP { it.copy(long = (it.long - 5).coerceAtLeast(5)) } }, { setP { it.copy(long = (it.long + 5).coerceAtMost(60)) } }) }
                SettingRow("Lamba break har", "${pm.every} sessions ke baad") { Stepper({ setP { it.copy(every = (it.every - 1).coerceAtLeast(2)) } }, { setP { it.copy(every = (it.every + 1).coerceAtMost(8)) } }) }
                SettingRow("Break auto shuru", "Focus ke baad turant break timer") { OneSwitch(pm.autoBreak) { v -> setP { it.copy(autoBreak = v) } } }
            }
        }

        // ---------------------------------------------------------------- marking
        item { SectionTitle("Marking scheme") }
        item {
            AppCard {
                SettingRow("Sahi answer", "+${f1(st.correct)}") {
                    Stepper({ upd(store) { it.copy(correct = (it.correct - 0.5).coerceAtLeast(0.5)) } }, { upd(store) { it.copy(correct = (it.correct + 0.5).coerceAtMost(5.0)) } })
                }
                SettingRow("Galat answer", "−${com.lakshya.study.core.f2(st.negative)}") {
                    Stepper({ upd(store) { it.copy(negative = (Math.round((it.negative - 0.25) * 100) / 100.0).coerceAtLeast(0.0)) } },
                        { upd(store) { it.copy(negative = (Math.round((it.negative + 0.25) * 100) / 100.0).coerceAtMost(2.0)) } })
                }
            }
        }

        // ---------------------------------------------------------------- behaviour
        item { SectionTitle("Behaviour") }
        item {
            AppCard {
                SettingRow("Haptic feedback", "Tap par halka vibration") { OneSwitch(st.haptics) { v -> upd(store) { it.copy(haptics = v) } } }
                SettingRow("Timer sound & vibration", "Session/break khatam hone par") { OneSwitch(st.sound) { v -> upd(store) { it.copy(sound = v) } } }
                SettingRow("Screen on rakho", "Timer chalte waqt screen band na ho") { OneSwitch(st.wake) { v -> upd(store) { it.copy(wake = v) } } }
                SettingRow("Roz ka reminder", "Padhai yaad dilane ke liye notification") {
                    OneSwitch(st.remind) { v -> if (v) ui.askNotif(); upd(store) { it.copy(remind = v) } }
                }
                if (st.remind) {
                    Label("Reminder time", Modifier.padding(top = 4.dp))
                    TimeField(st.remindTime, { v -> upd(store) { it.copy(remindTime = v) } })
                }
            }
        }

        // ---------------------------------------------------------------- data
        item { SectionTitle("Data") }
        item {
            AppCard {
                Btn("Backup save karo (.json)", { export.launch("lakshya-backup-${snap.today}.json") }, Modifier.fillMaxWidth(), kind = BtnKind.Soft)
                Spacer(Modifier.height(8.dp))
                Btn("Backup restore karo", {
                    ui.confirm("Restore karein?", "Abhi ka saara data backup se replace ho jayega.", "Choose file", danger = false) { restore() }
                }, Modifier.fillMaxWidth(), kind = BtnKind.Ghost)
                Tx("Purane Lakshya web app ka backup bhi yahan restore ho jata hai.", Modifier.padding(top = 8.dp), size = 12.sp, color = c.sub)
                Spacer(Modifier.height(14.dp))
                val hasDemo = s.tests.any { it.demo } || s.sessions.any { it.demo }
                Btn(
                    if (hasDemo) "Demo data hatao" else "Demo data load karo",
                    {
                        if (hasDemo) store.commit { removeDemo(it) } else store.commit { loadDemo(it, System.currentTimeMillis()) }
                    }, Modifier.fillMaxWidth(), kind = BtnKind.Ghost
                )
                Spacer(Modifier.height(8.dp))
                Btn("Sab kuch reset karo", {
                    ui.confirm("Sab reset?", "Saare subjects, tests, sessions aur notes hamesha ke liye delete ho jayenge. Pehle backup le lo.", "Reset") {
                        store.commit { AppState(settings = it.settings) }
                        ui.tab(com.lakshya.study.ui.Dest.Home)
                    }
                }, Modifier.fillMaxWidth(), kind = BtnKind.Danger)
            }
        }
        item {
            Tx("Lakshya · Study Companion\nData sirf is phone par rehta hai.", Modifier.fillMaxWidth().padding(vertical = 8.dp), size = 12.sp, color = c.sub, align = TextAlign.Center, lineHeight = 17.sp)
        }
    }
}

// ============================================================================ LOOK
@Composable
fun LookScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val st = snap.s.settings

    Screen("Theme & Look", onBack = { ui.back() }, subtitle = "Apne style me dhalo") {
        item {
            AppCard {
                Label("Interface style", Modifier.padding(top = 0.dp))
                Segmented(listOf("oneui" to "Samsung One UI", "coloros" to "OPPO ColorOS"), st.ui, { upd(store) { s -> s.copy(ui = it) } })
                Tx(
                    if (st.ui == "coloros") "Chhoti rounded corners, flat cards aur fresh green accent." else "Bade rounded cards, soft surfaces aur floating navigation.",
                    Modifier.padding(top = 8.dp), size = 12.5.sp, color = c.sub
                )
            }
        }
        item { SectionTitle("Theme") }
        item {
            AppCard {
                ChipFlow {
                    THEMES.forEach { th ->
                        val on = th.id == st.theme
                        Column(
                            Modifier.width(86.dp).clip(RoundedCornerShape(16.dp)).background(if (th.id == "system") c.surface2 else colorOf(th.bg))
                                .border(if (on) 2.5.dp else 1.dp, if (on) c.acc else c.line, RoundedCornerShape(16.dp))
                                .pressable(scaleTo = 0.94f) { ui.tick(); upd(store) { s -> s.copy(theme = th.id) } }.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(Modifier.size(16.dp).clip(CircleShape).background(colorOf(th.acc)))
                                Box(Modifier.size(16.dp).clip(CircleShape).background(colorOf(th.acc2)))
                            }
                            Tx(
                                th.name, Modifier.padding(top = 8.dp), size = 12.sp, weight = FontWeight.SemiBold, maxLines = 1,
                                color = if (th.id == "system") c.text else if (th.light) Color(0xFF16192A) else Color(0xFFF0F2F8)
                            )
                        }
                    }
                }
            }
        }
        item { SectionTitle("Accent") }
        item {
            AppCard {
                ChipFlow {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(c.surface2).border(if (st.accent.isEmpty()) 3.dp else 0.dp, c.text, CircleShape)
                                .pressable(scaleTo = 0.88f) { upd(store) { s -> s.copy(accent = "") } },
                            contentAlignment = Alignment.Center
                        ) { Tx("A", size = 15.sp, weight = FontWeight.Bold, overflow = androidx.compose.ui.text.style.TextOverflow.Clip) }
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Brush.sweepGradient(listOf(Color(0xFFFF6B6B), Color(0xFFFFD93D), Color(0xFF6BCB77), Color(0xFF4D96FF), Color(0xFFFF6B6B))))
                                .border(if (st.accent == "dynamic") 3.dp else 0.dp, c.text, CircleShape)
                                .pressable(scaleTo = 0.88f) { upd(store) { s -> s.copy(accent = "dynamic") } }
                        )
                    }
                    ACCENTS.forEach { (a, b) ->
                        Swatch(colorOf(a), st.accent == "$a,$b") { ui.tick(); upd(store) { s -> s.copy(accent = "$a,$b") } }
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) Tx("Rainbow = wallpaper ke colors (Material You).", Modifier.padding(top = 10.dp), size = 12.sp, color = c.sub)
            }
        }
        item { SectionTitle("Layout") }
        item {
            AppCard {
                Label("Card style", Modifier.padding(top = 0.dp))
                Segmented(listOf("soft" to "Soft", "outline" to "Outline", "elev" to "Raised"), st.card, { upd(store) { s -> s.copy(card = it) } })
                Label("Corners")
                Segmented(listOf("sharp" to "Sharp", "normal" to "Normal", "round" to "Round"), st.radius, { upd(store) { s -> s.copy(radius = it) } })
                Label("Spacing")
                Segmented(listOf("cozy" to "Cozy", "compact" to "Compact"), st.density, { upd(store) { s -> s.copy(density = it) } })
                Label("Navigation bar")
                Segmented(listOf("float" to "Floating", "bar" to "Full width"), st.nav, { upd(store) { s -> s.copy(nav = it) } })
            }
        }
        item { SectionTitle("Text") }
        item {
            AppCard {
                Label("Font", Modifier.padding(top = 0.dp))
                Segmented(listOf("default" to "Default", "serif" to "Serif", "mono" to "Mono"), st.font, { upd(store) { s -> s.copy(font = it) } })
                Label("Text size")
                Segmented(listOf("s" to "Small", "m" to "Medium", "l" to "Large"), st.fs, { upd(store) { s -> s.copy(fs = it) } })
            }
        }
        item { SectionTitle("Animations") }
        item {
            AppCard {
                Segmented(listOf("full" to "Full", "lite" to "Lite", "off" to "Off"), st.motion, { upd(store) { s -> s.copy(motion = it) } })
                Tx("Lite/Off purane phones par aur zyada smooth chalta hai aur battery bachata hai.", Modifier.padding(top = 8.dp), size = 12.sp, color = c.sub)
            }
        }
    }
}
