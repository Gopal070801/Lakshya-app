package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.Kind
import com.lakshya.study.core.REASONS
import com.lakshya.study.core.TEST_TYPES
import com.lakshya.study.core.deleteTest
import com.lakshya.study.core.f1
import com.lakshya.study.core.f2
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.insightsFor
import com.lakshya.study.core.pct
import com.lakshya.study.core.reasonOf
import com.lakshya.study.ui.Dest
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Badge
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.Divider
import com.lakshya.study.ui.components.Donut
import com.lakshya.study.ui.components.DonutItem
import com.lakshya.study.ui.components.EmojiBubble
import com.lakshya.study.ui.components.EmptyCard
import com.lakshya.study.ui.components.HBarRow
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ItemRow
import com.lakshya.study.ui.components.LineChart
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.RichTx
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.SectionTitle
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.StackBar
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Th

// ============================================================================ TESTS LIST
@Composable
fun TestsScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val s = snap.s
    val all = snap.sortedTests
    val shown = remember(all, ui.testsType) { all.filter { ui.testsType == "all" || it.type == ui.testsType }.reversed() }
    val trend = all.takeLast(10)

    Screen(
        "Mock Tests", subtitle = "${all.size} tests",
        actions = {
            IconBtn(Ic.Note, { ui.go(Dest.Notebook) }, bg = c.surface)
            IconBtn(Ic.Chart, { ui.go(Dest.Analysis) }, bg = c.surface)
        }
    ) {
        if (all.isEmpty()) {
            item {
                EmptyCard("📝", "Pehla mock test add karo", "Section-wise marks daalo, galtiyan log karo aur analysis dekho.") {
                    Btn("Test add karo", { ui.open(Sheet.TestForm(null)) }, big = true)
                }
            }
        } else {
            if (trend.size >= 2) item {
                AppCard {
                    val h0 = snap.headScore(trend.last())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Tx("${h0.label} score trend", size = 13.sp, weight = FontWeight.SemiBold, color = c.sub)
                            Tx("${f2(h0.score)} / ${f1(h0.max)}", size = 22.sp, weight = FontWeight.Bold)
                        }
                        Badge("Best acc ${f1(snap.bestAcc)}%", c.ok)
                    }
                    Spacer(Modifier.height(10.dp))
                    LineChart(trend.map { snap.headScore(it).score.toFloat() }, trend.map { fmtD(it.date) }, height = 130.dp, fmt = { f1(it.toDouble()) })
                }
            }
            val types = TEST_TYPES.filter { ty -> all.any { it.type == ty } }
            if (types.size > 1) item {
                ChipScroll {
                    Chip("Sab", ui.testsType == "all", { ui.testsType = "all" })
                    types.forEach { ty -> Chip(ty, ui.testsType == ty, { ui.testsType = ty }) }
                }
            }
            items(shown, key = { it.id }) { t ->
                val h = snap.headScore(t)
                val a = snap.agg(listOf(t), t.sections.keys)
                val (need, got) = snap.logProgress(t)
                AppCard(onClick = { ui.go(Dest.Test(t.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Tx(t.name, size = 16.sp, weight = FontWeight.Bold, maxLines = 1)
                            Tx(fmtD(t.date) + " · " + t.type + if (t.mins > 0) " · ${t.mins}m" else "", Modifier.padding(top = 2.dp), size = 12.sp, color = c.sub, maxLines = 1)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Tx(f2(h.score), size = 20.sp, weight = FontWeight.Bold, color = c.accText)
                            Tx("/ ${f1(h.max)} ${h.label}", size = 11.sp, color = c.sub)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    StackBar(a.correct, a.wrong, a.skip)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Tx("✅ ${a.correct}  ❌ ${a.wrong}  ⏭ ${a.skip}", size = 12.5.sp, color = c.sub)
                        Tx("Acc ${f1(a.acc)}%", size = 12.5.sp, weight = FontWeight.SemiBold)
                    }
                    if (need > 0 && got < need) {
                        Spacer(Modifier.height(8.dp))
                        Badge("📓 $got/$need galtiyan log hui", c.warn)
                    }
                }
            }
        }
    }
}

// ============================================================================ TEST DETAIL
@Composable
fun TestDetailScreen(id: String) {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val t = s.tests.firstOrNull { it.id == id }
    if (t == null) {
        Screen("Test", onBack = { ui.back() }) { item { EmptyCard("🤷", "Test nahi mila", "Ye delete ho chuka hai.") } }
        return
    }
    val st = snap.testStat(t)
    val h = snap.headScore(t)
    val a = snap.agg(listOf(t), t.sections.keys)
    val ms = s.mistakes.filter { it.testId == id }.sortedBy { it.created }
    val (need, got) = snap.logProgress(t)
    val pend = snap.pendingCombo(t, t.sections.keys)

    Screen(
        t.name, onBack = { ui.back() }, subtitle = fmtD(t.date) + " · " + t.type,
        actions = {
            IconBtn(Ic.Edit, { ui.open(Sheet.TestForm(id)) }, bg = c.surface)
            IconBtn(Ic.Trash, {
                ui.confirm("Test delete karein?", "Is test ki ${ms.size} logged galtiyan bhi hat jayengi.", "Delete") {
                    store.commit { it.deleteTest(id) }; ui.back()
                }
            }, tint = c.bad, bg = c.surface)
        }
    ) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx("${h.label} score", size = 13.sp, color = c.sub)
                        Tx("${f2(h.score)} / ${f1(h.max)}", size = 30.sp, weight = FontWeight.Bold, color = c.accText)
                        if (st.meritMax > 0 && st.totalMax != st.meritMax) Tx("Total: ${f2(st.total)} / ${f1(st.totalMax)}", size = 12.5.sp, color = c.sub)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Tx("${f1(a.acc)}%", size = 22.sp, weight = FontWeight.Bold)
                        Tx("accuracy", size = 11.5.sp, color = c.sub)
                    }
                }
                Spacer(Modifier.height(12.dp))
                StackBar(a.correct, a.wrong, a.skip, height = 10.dp)
                Spacer(Modifier.height(6.dp))
                Tx("✅ ${a.correct}   ❌ ${a.wrong}   ⏭ ${a.skip}   ·   attempt ${f1(a.attPct)}%", size = 12.5.sp, color = c.sub)
            }
        }
        item { SectionTitle("Section-wise") }
        items(st.secs.entries.toList(), key = { it.key }) { (sid, x) ->
            val sb = snap.sub(sid)
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EmojiBubble(sb.emoji, colorOf(sb.color), 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(sb.name + if (sb.merit) " ⭐" else "", size = 15.sp, weight = FontWeight.Bold, maxLines = 1)
                        Tx("✅ ${x.correct}  ❌ ${x.wrong}  ⏭ ${x.skip}  ·  ${f1(x.acc)}%", size = 12.sp, color = c.sub)
                    }
                    Tx("${f2(x.score)}/${f1(x.max)}", size = 15.sp, weight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                StackBar(x.correct, x.wrong, x.skip)
            }
        }
        item {
            SectionTitle("Galtiyan (${ms.size})" + if (need > 0) " · $got/$need log" else "")
        }
        if (pend != null) item {
            val sb = snap.sub(pend.sid)
            AppCard(container = c.accSoft, onClick = { ui.open(Sheet.MistakeForm(null, id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tx("📓", size = 24.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Tx("Agla log karo", size = 14.5.sp, weight = FontWeight.Bold, color = c.accText)
                        Tx(sb.name + " · " + if (pend.kind == Kind.SKIP) "skip kiye gaye" else "galat", size = 12.5.sp, color = c.accText)
                    }
                    Tx("+", size = 24.sp, color = c.accText)
                }
            }
        }
        if (ms.isNotEmpty()) item {
            AppCard {
                ms.forEachIndexed { i, m ->
                    val r = reasonOf(m.reason)
                    val sb = snap.sub(m.sid)
                    ItemRow(
                        snap.tName(m), sub = sb.short.ifEmpty { sb.name } + " · " + r.short + if (m.kind == Kind.SKIP) " · skip" else "",
                        emoji = r.ico, color = colorOf(r.color), onClick = { ui.open(Sheet.MistakeForm(m.id, null)) }
                    )
                    if (i < ms.size - 1) Divider()
                }
            }
        }
    }
}

// ============================================================================ ANALYSIS
@Composable
fun AnalysisScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val c = Th.c
    val s = snap.s
    val allIds = s.subjects.map { it.id }
    val meritIds = snap.meritIds(true).ifEmpty { allIds }
    val keys: List<String> = when (ui.anSec) {
        "merit" -> meritIds
        "all" -> allIds
        else -> if (allIds.contains(ui.anSec)) listOf(ui.anSec) else meritIds
    }
    val n = when (ui.anRange) { "5" -> 5; "10" -> 10; else -> Int.MAX_VALUE }
    val tests = snap.sortedTests.takeLast(n)
    val tids = tests.map { it.id }.toSet()
    val ms = s.mistakes.filter { it.testId in tids && it.sid in keys }
    val a = snap.agg(tests, keys)

    Screen("Analysis", onBack = { ui.back() }, subtitle = "Kahan marks ja rahe hain") {
        item {
            Column {
                ChipScroll {
                    if (snap.meritIds(true).isNotEmpty()) Chip("⭐ Merit", ui.anSec == "merit", { ui.anSec = "merit" })
                    Chip("Sab", ui.anSec == "all", { ui.anSec = "all" })
                    snap.activeSubs.forEach { sb -> Chip(sb.emoji + " " + snap.shortOf(sb), ui.anSec == sb.id, { ui.anSec = sb.id }, color = colorOf(sb.color)) }
                }
                Spacer(Modifier.height(10.dp))
                Segmented(listOf("5" to "Last 5", "10" to "Last 10", "all" to "Sab"), ui.anRange, { ui.anRange = it })
            }
        }
        if (tests.isEmpty()) {
            item { EmptyCard("📊", "Analysis ke liye test chahiye", "Kam se kam ek mock test add karo.") { Btn("Test add karo", { ui.open(Sheet.TestForm(null)) }) } }
            return@Screen
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("${tests.size}", "Tests", Modifier.weight(1f))
                StatTile(f1(a.acc) + "%", "Accuracy", Modifier.weight(1f), color = if (a.acc >= 75) c.ok else c.warn)
                StatTile(f1(a.attPct) + "%", "Attempt", Modifier.weight(1f))
                StatTile("-" + f2(a.wrong * snap.ng), "Neg. marks", Modifier.weight(1f), color = c.bad)
            }
        }
        item {
            AppCard {
                Tx("Score trend", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                Spacer(Modifier.height(8.dp))
                LineChart(tests.map { snap.agg(listOf(it), keys).score.toFloat() }, tests.map { fmtD(it.date) }, fmt = { f1(it.toDouble()) })
            }
        }
        item {
            AppCard {
                Tx("Subject-wise accuracy", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                keys.forEach { k ->
                    val sb = snap.subOrNull(k) ?: return@forEach
                    val ag = snap.agg(tests, listOf(k))
                    if (ag.total == 0) return@forEach
                    HBarRow(sb.emoji + " " + sb.name, "${f1(ag.acc)}% · ${ag.wrong}❌ ${ag.skip}⏭", (ag.acc / 100).toFloat(), colorOf(sb.color))
                }
            }
        }
        val ins = insightsFor(snap, tests, ms, keys)
        if (ins.isNotEmpty()) {
            item { SectionTitle("Insights") }
            items(ins) { i ->
                AppCard {
                    Row {
                        Tx(i.emoji, size = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            RichTx(i.title, size = 14.5.sp, boldColor = c.accText, lineHeight = 20.sp)
                            Tx(i.desc, Modifier.padding(top = 4.dp), size = 13.sp, color = c.sub, lineHeight = 18.sp)
                        }
                    }
                }
            }
        }
        if (ms.isNotEmpty()) {
            item {
                AppCard {
                    Tx("Galtiyon ke reasons", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                    Spacer(Modifier.height(12.dp))
                    val counts = REASONS.map { r -> r to ms.count { it.reason == r.key } }.filter { it.second > 0 }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Donut(counts.map { DonutItem(it.second.toFloat(), colorOf(it.first.color)) }, size = 116.dp, centerTop = "${ms.size}", centerSub = "galtiyan")
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            counts.sortedByDescending { it.second }.forEach { (r, k) ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.width(10.dp).height(10.dp).clip(RoundedCornerShape(3.dp)).background(colorOf(r.color)))
                                    Spacer(Modifier.width(8.dp))
                                    Tx(r.short, Modifier.weight(1f), size = 12.5.sp, maxLines = 1)
                                    Tx("$k · ${pct(k, ms.size)}%", size = 12.sp, color = c.sub)
                                }
                            }
                        }
                    }
                }
            }
            // subject x reason grid
            item {
                AppCard {
                    Tx("Subject × reason", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Box(Modifier.weight(1.5f))
                        REASONS.forEach { r -> Tx(r.ico, Modifier.weight(1f), size = 14.sp, align = TextAlign.Center) }
                    }
                    val mx = keys.maxOf { k -> REASONS.maxOf { r -> ms.count { it.sid == k && it.reason == r.key } } }.coerceAtLeast(1)
                    keys.forEach { k ->
                        val sb = snap.subOrNull(k) ?: return@forEach
                        if (ms.none { it.sid == k }) return@forEach
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Tx(snap.shortOf(sb), Modifier.weight(1.5f), size = 12.5.sp, weight = FontWeight.Medium, maxLines = 1)
                            REASONS.forEach { r ->
                                val k2 = ms.count { it.sid == k && it.reason == r.key }
                                Box(
                                    Modifier.weight(1f).padding(horizontal = 2.dp).height(30.dp).clip(RoundedCornerShape(8.dp))
                                        .background(if (k2 == 0) c.surface2 else c.acc.copy(alpha = 0.18f + 0.62f * k2 / mx)),
                                    contentAlignment = Alignment.Center
                                ) { if (k2 > 0) Tx("$k2", size = 12.sp, weight = FontWeight.Bold, color = c.text) }
                            }
                        }
                    }
                }
            }
            val weak = snap.topWeak(ms, 6)
            if (weak.isNotEmpty()) item {
                AppCard {
                    Tx("Sabse kamzor topics", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                    val mx = weak.maxOf { it.n }.coerceAtLeast(1)
                    weak.forEach { w ->
                        val sb = snap.sub(w.sid)
                        HBarRow(w.name, "${w.n} · ${reasonOf(w.top).short}", w.n.toFloat() / mx, colorOf(sb.color))
                    }
                    Spacer(Modifier.height(6.dp))
                    Btn("Notebook kholo", { ui.go(Dest.Notebook) }, kind = BtnKind.Soft)
                }
            }
        }
    }
}
