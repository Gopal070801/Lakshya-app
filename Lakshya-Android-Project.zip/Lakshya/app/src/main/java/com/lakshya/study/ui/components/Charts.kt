package com.lakshya.study.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.ui.theme.Motion
import com.lakshya.study.ui.theme.Th
import com.lakshya.study.ui.theme.Emphasized
import androidx.compose.animation.core.tween

/** 0 -> 1 progress that plays once when the chart appears (respects the motion setting). */
@Composable
fun rememberReveal(key: Any? = Unit, ms: Int = 800): State<Float> {
    val motion = Th.motion
    val a = remember(key) { Animatable(if (motion == Motion.Off) 1f else 0f) }
    LaunchedEffect(key) {
        if (motion == Motion.Off) a.snapTo(1f)
        else a.animateTo(1f, tween(if (motion == Motion.Lite) ms / 2 else ms, easing = Emphasized))
    }
    return a.asState()
}

// ====================================================================== ring
@Composable
fun Ring(
    progress: Float,                  // 0..1
    modifier: Modifier = Modifier,
    size: Dp = 86.dp,
    stroke: Dp = 8.dp,
    color: Color = Th.c.acc,
    track: Color = Th.c.surface2,
    content: @Composable () -> Unit = {}
) {
    val p = rememberReveal(progress)
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val inset = sw / 2
            val arc = Size(this.size.width - sw, this.size.height - sw)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(sw))
            val sweep = 360f * progress.coerceIn(0f, 1f) * p.value
            if (sweep > 0.5f) drawArc(color, -90f, sweep, false, Offset(inset, inset), arc, style = Stroke(sw, cap = StrokeCap.Round))
        }
        content()
    }
}

// ====================================================================== donut
class DonutItem(val value: Float, val color: Color)

@Composable
fun Donut(items: List<DonutItem>, modifier: Modifier = Modifier, size: Dp = 112.dp, centerTop: String, centerSub: String) {
    val total = items.sumOf { it.value.toDouble() }.toFloat().coerceAtLeast(0.0001f)
    val p = rememberReveal(items.size + total)
    val c = Th.c
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = this.size.width * 0.16f
            val inset = sw / 2
            val arc = Size(this.size.width - sw, this.size.height - sw)
            drawArc(c.surface2, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(sw))
            var start = -90f
            for (it in items) {
                val sweepFull = it.value / total * 360f
                val sweep = (sweepFull - 2.2f).coerceAtLeast(0f) * p.value
                if (sweep > 0f) drawArc(it.color, start + 1.1f, sweep, false, Offset(inset, inset), arc, style = Stroke(sw))
                start += sweepFull
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(centerTop, size = 20.sp, weight = FontWeight.Bold, maxLines = 1)
            Tx(centerSub, size = 11.sp, color = c.sub, maxLines = 1)
        }
    }
}

// ====================================================================== bar chart
@Composable
fun BarChart(
    values: List<Float>,
    labels: List<String>,
    modifier: Modifier = Modifier,
    height: Dp = 130.dp,
    color: Color = Th.c.acc,
    goal: Float = 0f,
    highlight: Int = -1,
    colors: List<Color>? = null,
    valueLabel: ((Float) -> String)? = null
) {
    if (values.isEmpty()) { Tx("Data nahi hai", Modifier.fillMaxWidth(), size = 13.sp, color = Th.c.sub, align = TextAlign.Center); return }
    val c = Th.c
    val p = rememberReveal(values.size + values.sum())
    val mx = maxOf(goal, values.maxOrNull() ?: 0f, 1f)
    val n = values.size
    val step = if (n > 14) (if (n > 24) 5 else 2) else 1
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(height)) {
            val w = size.width
            val h = size.height
            val top = 14.dp.toPx()
            val ch = h - top
            val bw = w / n
            val gap = minOf(7.dp.toPx(), bw * 0.3f)
            drawLine(c.line.copy(alpha = 0.2f), Offset(0f, h), Offset(w, h), 1.dp.toPx())
            if (goal > 0f) {
                val y = h - ch * goal / mx
                var x = 0f
                while (x < w) { drawLine(c.ok.copy(alpha = 0.7f), Offset(x, y), Offset(minOf(x + 5.dp.toPx(), w), y), 1.dp.toPx()); x += 9.dp.toPx() }
            }
            for (i in 0 until n) {
                val v = values[i]
                val bh = ch * (v / mx) * p.value
                val x = i * bw + gap / 2
                val bwid = bw - gap
                val col = colors?.getOrNull(i) ?: color
                val a = if (highlight < 0 || highlight == i) 1f else 0.78f
                if (v > 0f) {
                    val hh = maxOf(2.dp.toPx(), bh)
                    drawRoundRect(col.copy(alpha = a), Offset(x, h - hh), Size(bwid, hh), CornerRadius(minOf(6.dp.toPx(), bwid / 2)))
                } else {
                    drawRoundRect(c.surface2, Offset(x, h - 3.dp.toPx()), Size(bwid, 3.dp.toPx()), CornerRadius(2.dp.toPx()))
                }
            }
        }
        if (valueLabel != null && n <= 8) {
            Row(Modifier.fillMaxWidth()) {
                values.forEach { Tx(if (it > 0f) valueLabel(it) else "", Modifier.weight(1f), size = 9.5.sp, color = c.sub, align = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Clip) }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                val show = (i % step == 0 || i == n - 1) && l.isNotEmpty()
                Tx(if (show) l else "", Modifier.weight(1f), size = 10.5.sp, color = c.sub, align = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Clip)
            }
        }
    }
}

// ====================================================================== line chart
@Composable
fun LineChart(
    values: List<Float>,
    labels: List<String>,
    modifier: Modifier = Modifier,
    height: Dp = 150.dp,
    color: Color = Th.c.acc,
    minV: Float? = null,
    maxV: Float? = null,
    target: Float? = null,
    fmt: (Float) -> String = { Math.round(it).toString() }
) {
    if (values.isEmpty()) { Tx("Data nahi hai", Modifier.fillMaxWidth(), size = 13.sp, color = Th.c.sub, align = TextAlign.Center); return }
    val c = Th.c
    val p = rememberReveal(values.size + values.sum())
    var mn = minV ?: values.min()
    var mx = maxV ?: values.max()
    if (minV == null) {
        if (mx == mn) { mx += 1f; mn -= 1f }
        val pad = (mx - mn) * 0.12f
        mn -= pad; mx += pad
    } else if (mx == mn) mx = mn + 1f
    val n = values.size
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(height)) {
            Column(Modifier.width(30.dp).height(height), verticalArrangement = Arrangement.SpaceBetween) {
                Tx(fmt(mx), size = 9.5.sp, color = c.sub, maxLines = 1)
                Tx(fmt((mx + mn) / 2), size = 9.5.sp, color = c.sub, maxLines = 1)
                Tx(fmt(mn), size = 9.5.sp, color = c.sub, maxLines = 1)
            }
            Canvas(Modifier.weight(1f).height(height)) {
                val w = size.width
                val h = size.height
                val padX = 10.dp.toPx()
                val padY = 10.dp.toPx()
                fun xAt(i: Int) = if (n == 1) w / 2 else padX + i * (w - 2 * padX) / (n - 1)
                fun yAt(v: Float) = padY + (h - 2 * padY) * (1f - (v - mn) / (mx - mn))
                for (f in listOf(0f, 0.5f, 1f)) {
                    val y = padY + (h - 2 * padY) * f
                    drawLine(c.line.copy(alpha = 0.18f), Offset(0f, y), Offset(w, y), 1.dp.toPx())
                }
                if (target != null && target >= mn && target <= mx) {
                    val y = yAt(target)
                    var x = 0f
                    while (x < w) { drawLine(c.ok.copy(alpha = 0.8f), Offset(x, y), Offset(minOf(x + 5.dp.toPx(), w), y), 1.dp.toPx()); x += 9.dp.toPx() }
                }
                val pts = values.mapIndexed { i, v -> Offset(xAt(i), yAt(v)) }
                val shown = (pts.size * p.value).coerceAtLeast(1f)
                val full = shown.toInt().coerceIn(1, pts.size)
                val path = Path()
                val area = Path()
                path.moveTo(pts[0].x, pts[0].y)
                area.moveTo(pts[0].x, h)
                area.lineTo(pts[0].x, pts[0].y)
                var lastX = pts[0].x
                var lastY = pts[0].y
                for (i in 1 until full) {
                    // smooth curve
                    val prev = pts[i - 1]
                    val cur = pts[i]
                    val mid = (prev.x + cur.x) / 2
                    path.cubicTo(mid, prev.y, mid, cur.y, cur.x, cur.y)
                    area.cubicTo(mid, prev.y, mid, cur.y, cur.x, cur.y)
                    lastX = cur.x; lastY = cur.y
                }
                if (full < pts.size) {
                    val frac = shown - full
                    val prev = pts[full - 1]
                    val nxt = pts[full]
                    lastX = prev.x + (nxt.x - prev.x) * frac
                    lastY = prev.y + (nxt.y - prev.y) * frac
                    path.lineTo(lastX, lastY); area.lineTo(lastX, lastY)
                }
                area.lineTo(lastX, h)
                area.close()
                drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), color.copy(alpha = 0f)), 0f, h))
                drawPath(path, color, style = Stroke(2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                for (i in 0 until full) {
                    drawCircle(c.surface, 4.6.dp.toPx(), pts[i])
                    drawCircle(color, 3.2.dp.toPx(), pts[i])
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 30.dp)) {
            labels.forEachIndexed { i, l ->
                val show = n <= 8 || i == 0 || i == n - 1 || i % 2 == 0
                Tx(if (show) l else "", Modifier.weight(1f), size = 10.5.sp, color = c.sub, align = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Clip)
            }
        }
    }
}

// ====================================================================== sparkline
@Composable
fun Spark(values: List<Float>, modifier: Modifier = Modifier, color: Color = Th.c.acc, width: Dp = 84.dp, height: Dp = 26.dp) {
    if (values.size < 2) return
    val p = rememberReveal(values.size + values.sum(), 700)
    Canvas(modifier.size(width, height)) {
        val mn = values.min()
        val mx = values.max()
        val r = if (mx - mn == 0f) 1f else mx - mn
        val w = size.width
        val h = size.height
        val pts = values.mapIndexed { i, v -> Offset(i * w / (values.size - 1), h - 3.dp.toPx() - (v - mn) / r * (h - 6.dp.toPx())) }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        val upto = ((pts.size - 1) * p.value)
        val full = upto.toInt()
        for (i in 1..full) path.lineTo(pts[i].x, pts[i].y)
        if (full < pts.size - 1) {
            val f = upto - full
            path.lineTo(pts[full].x + (pts[full + 1].x - pts[full].x) * f, pts[full].y + (pts[full + 1].y - pts[full].y) * f)
        }
        drawPath(path, color, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

// ====================================================================== bars
@Composable
fun StackBar(correct: Int, wrong: Int, skip: Int, modifier: Modifier = Modifier, height: Dp = 8.dp) {
    val c = Th.c
    val total = (correct + wrong + skip).coerceAtLeast(1).toFloat()
    val p = rememberReveal(correct + wrong * 31 + skip * 977, 700)
    Canvas(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50))) {
        drawRect(c.surface2)
        var x = 0f
        val w = size.width * p.value
        fun seg(v: Int, col: Color) { if (v > 0) { val sw = w * v / total; drawRect(col, Offset(x, 0f), Size(sw, size.height)); x += sw } }
        seg(correct, c.ok); seg(wrong, c.bad); seg(skip, c.skip)
    }
}

/** Generic progress bar with up to two layered fills (done, partial). */
@Composable
fun ProgressBar(frac: Float, color: Color, modifier: Modifier = Modifier, frac2: Float = 0f, height: Dp = 8.dp, brush: Brush? = null) {
    val c = Th.c
    val p = rememberReveal(frac + frac2)
    Canvas(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50))) {
        drawRect(c.surface2)
        val w = size.width
        val a = frac.coerceIn(0f, 1f) * w * p.value
        val b = (frac + frac2).coerceIn(0f, 1f) * w * p.value
        if (frac2 > 0f) drawRect(color.copy(alpha = 0.42f), Offset.Zero, Size(b, size.height))
        if (a > 0f) {
            if (brush != null) drawRect(brush, Offset.Zero, Size(a, size.height)) else drawRect(color, Offset.Zero, Size(a, size.height))
        }
    }
}

// ====================================================================== heatmap
@Composable
fun Heatmap(cells: List<Float?>, weeks: Int, modifier: Modifier = Modifier) {
    // cells: day-major per week (7 per column); null = future day; value = ratio of goal (0..)
    val c = Th.c
    val p = rememberReveal(cells.size, 600)
    Canvas(modifier.fillMaxWidth().aspectRatio(weeks / 7f)) {
        val gap = 3.dp.toPx()
        val cw = (size.width - gap * (weeks - 1)) / weeks
        for (w in 0 until weeks) for (d in 0 until 7) {
            val v = cells.getOrNull(w * 7 + d)
            if (v == null) continue
            val o = if (v <= 0f) 0f else if (v < .25f) .28f else if (v < .5f) .46f else if (v < 1f) .72f else 1f
            val x = w * (cw + gap)
            val y = d * (cw + gap)
            drawRoundRect(c.surface2, Offset(x, y), Size(cw, cw), CornerRadius(cw * 0.28f))
            if (o > 0f) drawRoundRect(c.acc.copy(alpha = o * p.value), Offset(x, y), Size(cw, cw), CornerRadius(cw * 0.28f))
        }
    }
}

@Composable
fun HBarRow(title: String, right: String, frac: Float, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Tx(title, Modifier.weight(1f), size = 14.sp, weight = FontWeight.SemiBold, maxLines = 1)
            Tx(right, size = 12.5.sp, color = Th.c.sub, maxLines = 1)
        }
        Box(Modifier.height(6.dp))
        ProgressBar(frac, color)
    }
}
