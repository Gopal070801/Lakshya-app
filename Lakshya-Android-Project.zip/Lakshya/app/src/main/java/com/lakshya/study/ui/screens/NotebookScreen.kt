package com.lakshya.study.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.BOX
import com.lakshya.study.core.Kind
import com.lakshya.study.core.REASONS
import com.lakshya.study.core.answerCard
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.reasonOf
import com.lakshya.study.core.toggleMistakeDone
import com.lakshya.study.ui.LocalSnap
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.NbFilter
import com.lakshya.study.ui.Sheet
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Badge
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.CheckCircle
import com.lakshya.study.ui.components.Chip
import com.lakshya.study.ui.components.ChipScroll
import com.lakshya.study.ui.components.EmptyCard
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Ic
import com.lakshya.study.ui.components.IconBtn
import com.lakshya.study.ui.components.ProgressBar
import com.lakshya.study.ui.components.Screen
import com.lakshya.study.ui.components.Segmented
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.components.colorOf
import com.lakshya.study.ui.theme.Motion
import com.lakshya.study.ui.theme.Th
import com.lakshya.study.ui.theme.tweenSpec

// ============================================================================ NOTEBOOK
@Composable
fun NotebookScreen() {
    val snap = LocalSnap.current
    val ui = LocalUi.current
    val store = LocalStore.current
    val c = Th.c
    val s = snap.s
    val f = ui.nb

    val list = remember(s.mistakes, f, snap.today) {
        s.mistakes.filter { m ->
            (when (f.status) { "due" -> snap.cardDue(m); "done" -> m.done; else -> true }) &&
                (f.sid == "all" || m.sid == f.sid) &&
                (f.reason == "all" || m.reason == f.reason) &&
                (f.tid.isEmpty() || m.tid == f.tid) &&
                (f.q.isBlank() || m.q.contains(f.q.trim(), true) || m.ans.contains(f.q.trim(), true) || snap.tName(m).contains(f.q.trim(), true))
        }.sortedByDescending { it.created }
    }
    val dueIds = list.filter { snap.cardDue(it) }.map { it.id }
    val mastered = s.mistakes.count { it.done }

    Screen(
        "Notebook", onBack = { ui.back() }, subtitle = "${s.mistakes.size} cards · ${snap.dueCards.size} due · $mastered mastered",
        actions = { IconBtn(Ic.Plus, { ui.open(Sheet.MistakeForm(null, null)) }, bg = c.surface) }
    ) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx(if (dueIds.isEmpty()) "Sab revise ho gaya 🎉" else "${dueIds.size} cards revise karo", size = 16.sp, weight = FontWeight.Bold)
                        Tx("Spaced repetition: galat card jaldi wapas aata hai.", size = 12.5.sp, color = c.sub)
                    }
                    Btn("Revise", { ui.startRevise(dueIds.take(30)) }, icon = Ic.Cards, enabled = dueIds.isNotEmpty())
                }
            }
        }
        item {
            Column {
                Segmented(listOf("due" to "Due", "all" to "Sab", "done" to "Mastered"), f.status, { ui.nb = NbFilter(it, f.sid, f.reason, f.tid, f.q) })
                Spacer(Modifier.height(10.dp))
                ChipScroll {
                    Chip("Sab subjects", f.sid == "all", { ui.nb = NbFilter(f.status, "all", f.reason, f.tid, f.q) })
                    snap.activeSubs.forEach { sb -> Chip(sb.emoji + " " + snap.shortOf(sb), f.sid == sb.id, { ui.nb = NbFilter(f.status, sb.id, f.reason, f.tid, f.q) }, color = colorOf(sb.color)) }
                }
                Spacer(Modifier.height(8.dp))
                ChipScroll {
                    Chip("Sab reasons", f.reason == "all", { ui.nb = NbFilter(f.status, f.sid, "all", f.tid, f.q) })
                    REASONS.forEach { r -> Chip(r.ico + " " + r.short, f.reason == r.key, { ui.nb = NbFilter(f.status, f.sid, r.key, f.tid, f.q) }, color = colorOf(r.color)) }
                }
                if (f.tid.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    ChipScroll { Chip("Topic: " + (snap.topic(f.tid)?.name ?: "?") + "  ✕", true, { ui.nb = NbFilter(f.status, f.sid, f.reason, "", f.q) }) }
                }
                if (s.mistakes.size > 6) { Spacer(Modifier.height(10.dp)); Field(f.q, { ui.nb = NbFilter(f.status, f.sid, f.reason, f.tid, it) }, hint = "Search…") }
            }
        }
        if (list.isEmpty()) item {
            EmptyCard(
                "📓", if (s.mistakes.isEmpty()) "Notebook khaali hai" else "Is filter me kuch nahi",
                if (s.mistakes.isEmpty()) "Mock test ki galtiyan yahan log hoti hain, ya + se manual note banao." else "Filter badal ke dekho."
            )
        } else items(list.take(150), key = { it.id }) { m ->
            val r = reasonOf(m.reason)
            val sb = snap.sub(m.sid)
            AppCard(onClick = { ui.open(Sheet.MistakeForm(m.id, null)) }, accent = colorOf(r.color)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Tx(r.ico, size = 15.sp)
                            Spacer(Modifier.width(6.dp))
                            Tx(snap.tName(m), Modifier.weight(1f), size = 15.sp, weight = FontWeight.Bold, maxLines = 2)
                        }
                        Tx(sb.emoji + " " + sb.name + " · " + r.short + when (m.kind) { Kind.SKIP -> " · skip"; Kind.NOTE -> " · note"; else -> "" }, Modifier.padding(top = 2.dp), size = 12.sp, color = c.sub, maxLines = 1)
                    }
                    CheckCircle(m.done) { ui.tick(); store.commit { it.toggleMistakeDone(m.id, snap.today) } }
                }
                if (m.q.isNotBlank()) Tx(m.q, Modifier.padding(top = 8.dp), size = 14.sp, lineHeight = 20.sp, maxLines = 4)
                if (m.ans.isNotBlank()) Tx("✔ " + m.ans, Modifier.padding(top = 6.dp), size = 13.5.sp, color = c.ok, lineHeight = 19.sp, maxLines = 4)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                        for (i in 0 until BOX.size) Box(Modifier.size(width = 18.dp, height = 5.dp).clip(RoundedCornerShape(50)).background(if (i < m.box) c.ok else c.surface2))
                    }
                    Tx(
                        when { m.done -> "Mastered ✅"; snap.cardDue(m) -> "Due"; else -> "Next " + fmtD(m.due) },
                        size = 11.5.sp, color = if (!m.done && snap.cardDue(m)) c.warn else c.sub
                    )
                }
            }
        }
    }
}

// ============================================================================ FLASHCARDS
@Composable
fun FlashcardOverlay(ids: List<String>, onClose: () -> Unit) {
    val snap = LocalSnap.current
    val store = LocalStore.current
    val c = Th.c
    var idx by remember(ids) { mutableIntStateOf(0) }
    var good by remember(ids) { mutableIntStateOf(0) }
    var hard by remember(ids) { mutableIntStateOf(0) }
    var again by remember(ids) { mutableIntStateOf(0) }
    val total = ids.size
    val m = ids.getOrNull(idx)?.let { id -> snap.s.mistakes.firstOrNull { it.id == id } }
    val finished = idx >= total
    val density = LocalDensity.current.density

    Box(
        Modifier.fillMaxSize().background(c.bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Ic.Close, onClose, bg = c.surface)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Tx(if (finished) "Done!" else "${idx + 1} / $total", size = 14.sp, weight = FontWeight.SemiBold, color = c.sub)
                    Spacer(Modifier.height(6.dp))
                    ProgressBar((idx.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f), c.acc)
                }
            }
            Spacer(Modifier.height(18.dp))

            if (finished) {
                Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Tx("🎉", size = 64.sp, overflow = androidx.compose.ui.text.style.TextOverflow.Clip)
                    Tx("Revision complete", Modifier.padding(top = 12.dp), size = 24.sp, weight = FontWeight.Bold)
                    Tx("✅ $good yaad   😐 $hard mushkil   🔁 $again dobara", Modifier.padding(top = 8.dp), size = 14.sp, color = c.sub)
                    Spacer(Modifier.height(24.dp))
                    Btn("Wapas jao", onClose, big = true)
                }
            } else if (m == null) {
                // card vanished (deleted elsewhere): skip it
                androidx.compose.runtime.LaunchedEffect(idx) { idx += 1 }
            } else androidx.compose.runtime.key(idx) {
                var flipped by remember { mutableStateOf(false) }
                val rot by animateFloatAsState(if (flipped) 180f else 0f, tweenSpec(380), label = "flip")
                val r = reasonOf(m.reason)
                val sb = snap.sub(m.sid)
                Box(
                    Modifier.weight(1f).fillMaxWidth()
                        .graphicsLayer { rotationY = rot; cameraDistance = 14f * density }
                        .clip(RoundedCornerShape(Th.d.card + 6.dp)).background(c.surface)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { flipped = !flipped }
                ) {
                    if (rot <= 90f) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Badge(sb.emoji + " " + sb.name + " · " + r.short, colorOf(r.color))
                            Tx(snap.tName(m), Modifier.padding(top = 18.dp), size = 22.sp, weight = FontWeight.Bold, align = TextAlign.Center)
                            Tx(
                                m.q.ifBlank { "Is topic ka concept yaad karo." }, Modifier.padding(top = 14.dp), size = 17.sp,
                                align = TextAlign.Center, lineHeight = 25.sp, color = c.text
                            )
                            Tx("Tap karke jawab dekho", Modifier.padding(top = 28.dp), size = 12.5.sp, color = c.sub)
                        }
                    } else {
                        Column(
                            Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }.verticalScroll(rememberScrollState()).padding(24.dp),
                            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Tx("SAHI JAWAB", size = 11.5.sp, weight = FontWeight.SemiBold, color = c.sub)
                            Tx(m.ans.ifBlank { "Jawab save nahi hai. Notes me dekho." }, Modifier.padding(top = 10.dp), size = 20.sp, weight = FontWeight.SemiBold, color = c.ok, align = TextAlign.Center, lineHeight = 28.sp)
                            Tx(r.ico + " " + r.label, Modifier.padding(top = 22.dp), size = 13.sp, weight = FontWeight.SemiBold, align = TextAlign.Center)
                            Tx(r.fix, Modifier.padding(top = 4.dp), size = 13.sp, color = c.sub, align = TextAlign.Center, lineHeight = 19.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (flipped) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Btn("🔁 Dobara", { again++; store.commit { it.answerCard(m.id, "again", snap.today) }; idx++ }, Modifier.weight(1f), kind = BtnKind.Danger, big = true)
                        Btn("😐 Mushkil", { hard++; store.commit { it.answerCard(m.id, "hard", snap.today) }; idx++ }, Modifier.weight(1f), kind = BtnKind.Ghost, big = true)
                        Btn("✅ Yaad", { good++; store.commit { it.answerCard(m.id, "good", snap.today) }; idx++ }, Modifier.weight(1f), big = true)
                    }
                } else {
                    Btn("Jawab dikhao", { flipped = true }, Modifier.fillMaxWidth(), big = true)
                }
            }
        }
    }
}
