package com.lakshya.study

import android.app.Application
import com.lakshya.study.data.Store
import com.lakshya.study.notify.Notifier

class LakshyaApp : Application() {
    lateinit var store: Store
        private set

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        store = Store(this)
        val s = store.state.value
        Notifier.syncReminder(this, s.settings)
        Notifier.syncTimer(this, s, System.currentTimeMillis())
    }
}
