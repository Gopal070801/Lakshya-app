package com.lakshya.study

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.lakshya.study.ui.LakshyaRoot

class MainActivity : ComponentActivity() {

    private val store get() = (application as LakshyaApp).store

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        handle(intent)
        setContent { LakshyaRoot(store) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        when (i?.action) {
            "com.lakshya.study.action.FOCUS" -> store.openRequest.value = "focus"
            "com.lakshya.study.action.ADD_TEST" -> store.openRequest.value = "test"
            "com.lakshya.study.action.NOTEBOOK" -> store.openRequest.value = "notebook"
        }
    }

    override fun onResume() {
        super.onResume()
        store.onForeground()
    }

    override fun onStop() {
        super.onStop()
        store.flushNow()
    }
}
