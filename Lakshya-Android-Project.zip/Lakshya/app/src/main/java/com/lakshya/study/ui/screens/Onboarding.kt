package com.lakshya.study.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.loadPreset
import com.lakshya.study.ui.LocalStore
import com.lakshya.study.ui.LocalUi
import com.lakshya.study.ui.components.AppCard
import com.lakshya.study.ui.components.Btn
import com.lakshya.study.ui.components.BtnKind
import com.lakshya.study.ui.components.DateField
import com.lakshya.study.ui.components.Field
import com.lakshya.study.ui.components.Label
import com.lakshya.study.ui.components.OneSwitch
import com.lakshya.study.ui.components.SettingRow
import com.lakshya.study.ui.components.Stepper
import com.lakshya.study.ui.components.Tx
import com.lakshya.study.ui.theme.Th

@Composable
fun Onboarding() {
    val c = Th.c
    val store = LocalStore.current
    val ui = LocalUi.current
    var name by remember { mutableStateOf("") }
    var exam by remember { mutableStateOf("SSC MTS") }
    var date by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf(240) }
    var preset by remember { mutableStateOf(true) }
    val restore = rememberRestoreLauncher { ok ->
        ui.toast(if (ok) "Backup restore ho gaya ✅" else "Ye file valid backup nahi hai", if (ok) "ok" else "bad")
    }

    Box(
        Modifier.fillMaxSize().background(c.bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.androidxSize(84).background(c.grad, androidx.compose.foundation.shape.RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) { Tx("🎯", size = 40.sp, overflow = androidx.compose.ui.text.style.TextOverflow.Clip) }
            Tx("Lakshya", Modifier.padding(top = 16.dp), size = 34.sp, weight = FontWeight.Bold)
            Tx("Tumhara study companion. Planner, focus timer, mock analysis aur revision, sab ek jagah.", Modifier.padding(top = 6.dp, bottom = 18.dp), size = 14.sp, color = c.sub, align = TextAlign.Center, lineHeight = 20.sp)

            AppCard {
                Label("Tumhara naam", Modifier.padding(top = 0.dp))
                Field(name, { name = it }, hint = "Naam (optional)", maxLen = 30)
                Label("Exam")
                Field(exam, { exam = it }, hint = "SSC MTS", maxLen = 40)
                Label("Exam date (optional)")
                DateField(date, { date = it }, allowClear = true, placeholder = "Exam date chuno")
                SettingRow("Roz ka goal", "${goal / 60}h ${goal % 60}m") {
                    Stepper({ goal = (goal - 30).coerceAtLeast(30) }, { goal = (goal + 30).coerceAtMost(960) })
                }
                SettingRow("SSC MTS syllabus load karo", "GA, English, Maths, Reasoning ke topics") { OneSwitch(preset) { preset = it } }
            }
            Spacer(Modifier.height(16.dp))
            Btn("Shuru karo 🚀", {
                store.commit { st ->
                    val p = st.profile.copy(
                        name = name.trim(), exam = exam.trim().ifEmpty { "SSC MTS" }, examDate = date,
                        dailyGoal = goal, onboarded = true
                    )
                    val n = st.copy(profile = p)
                    if (preset) n.loadPreset() else n
                }
                ui.askNotif()
            }, Modifier.fillMaxWidth(), big = true)
            Spacer(Modifier.height(8.dp))
            Btn("Purana backup restore karo", restore, Modifier.fillMaxWidth(), kind = BtnKind.Ghost)
            Tx("Purane Lakshya web app ka backup (.json) bhi chalega.", Modifier.padding(top = 8.dp), size = 12.sp, color = c.sub, align = TextAlign.Center)
        }
    }
}

private fun Modifier.androidxSize(dp: Int): Modifier = this.then(Modifier.size(dp.dp))
