package com.lakshya.study.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lakshya.study.core.fmtD
import com.lakshya.study.core.hexInt
import com.lakshya.study.core.isValidDate
import com.lakshya.study.core.pad2
import com.lakshya.study.core.parseD
import com.lakshya.study.core.to12
import com.lakshya.study.ui.theme.LocalAppFont
import com.lakshya.study.ui.theme.Motion
import com.lakshya.study.ui.theme.Th
import com.lakshya.study.ui.theme.tweenSpec

fun colorOf(hex: String): Color = Color(hexInt(hex))

// ====================================================================== text
@Composable
fun Tx(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 15.sp,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Ellipsis
) {
    BasicText(
        text = text, modifier = modifier, maxLines = maxLines, overflow = overflow,
        style = TextStyle(
            color = if (color == Color.Unspecified) Th.c.text else color, fontSize = size, fontWeight = weight,
            fontFamily = LocalAppFont.current, textAlign = align ?: TextAlign.Unspecified, lineHeight = lineHeight
        )
    )
}

/** Text with **bold** markers. */
@Composable
fun RichTx(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 14.sp,
    color: Color = Color.Unspecified,
    boldColor: Color = Color.Unspecified,
    lineHeight: TextUnit = TextUnit.Unspecified
) {
    val base = if (color == Color.Unspecified) Th.c.text else color
    val bold = if (boldColor == Color.Unspecified) Th.c.text else boldColor
    val ann: AnnotatedString = remember(text, bold) {
        buildAnnotatedString {
            val parts = text.split("**")
            parts.forEachIndexed { i, p ->
                if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = bold)) { append(p) } else append(p)
            }
        }
    }
    BasicText(
        text = ann, modifier = modifier,
        style = TextStyle(color = base, fontSize = size, fontFamily = LocalAppFont.current, lineHeight = lineHeight)
    )
}

// ====================================================================== press feedback
@Composable
fun Modifier.pressable(
    enabled: Boolean = true,
    scaleTo: Float = 0.97f,
    onClick: () -> Unit
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val motion = Th.motion
    val sc by animateFloatAsState(
        targetValue = if (pressed && motion != Motion.Off) scaleTo else 1f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 650f), label = "press"
    )
    return this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

// ====================================================================== cards
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    accent: Color? = null,
    padding: Dp? = null,
    container: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Th.c
    val d = Th.d
    val shape = RoundedCornerShape(d.card)
    var m = modifier.fillMaxWidth()
    if (d.cardStyle == "elev") m = m.shadow(if (c.light) 6.dp else 10.dp, shape, ambientColor = Color(0x22000000), spotColor = Color(0x33000000))
    m = m.clip(shape).background(container ?: c.surface)
    if (d.cardStyle == "outline") m = m.border(BorderStroke(1.dp, c.line.copy(alpha = if (c.light) 0.16f else 0.22f)), shape)
    if (onClick != null) m = m.pressable(scaleTo = 0.975f, onClick = onClick)
    Box(m) {
        Column(Modifier.fillMaxWidth().padding(padding ?: d.pad), content = content)
        if (accent != null) Box(Modifier.align(Alignment.CenterStart).width(4.dp).height(36.dp).clip(RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp)).background(accent))
    }
}

@Composable
fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 2.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Tx(title, Modifier.weight(1f), size = 14.sp, weight = FontWeight.SemiBold, color = Th.c.sub)
        if (action != null && onAction != null) {
            Tx(action, Modifier.pressable(onClick = onAction).padding(8.dp), size = 13.sp, weight = FontWeight.SemiBold, color = Th.c.accText)
        }
    }
}

@Composable
fun EmojiBubble(emoji: String, color: Color, size: Dp = 42.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.34f)).background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) { Tx(emoji, size = (size.value * 0.46f).sp, align = TextAlign.Center, overflow = TextOverflow.Clip) }
}

@Composable
fun Badge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Tx(text, size = 11.sp, weight = FontWeight.SemiBold, color = color, maxLines = 1)
    }
}

@Composable
fun Divider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(Th.c.line))
}

/** One list row: bubble + two lines + trailing. */
@Composable
fun ItemRow(
    title: String,
    modifier: Modifier = Modifier,
    sub: String? = null,
    emoji: String? = null,
    color: Color = Th.c.acc,
    done: Boolean = false,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (RowScope.() -> Unit)? = null,
    leading: @Composable (RowScope.() -> Unit)? = null
) {
    val m = if (onClick != null) modifier.pressable(scaleTo = 0.985f, onClick = onClick) else modifier
    Row(m.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (leading != null) { leading(); Spacer(Modifier.width(12.dp)) }
        if (emoji != null) { EmojiBubble(emoji, color); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f).alpha(if (done) 0.5f else 1f)) {
            Tx(title, size = 15.sp, weight = FontWeight.SemiBold, maxLines = 2)
            if (sub != null) Tx(sub, Modifier.padding(top = 2.dp), size = 12.5.sp, color = Th.c.sub, maxLines = 2)
        }
        if (trailing != null) { Spacer(Modifier.width(8.dp)); trailing() }
    }
}

@Composable
fun CheckCircle(checked: Boolean, onClick: () -> Unit) {
    val c = Th.c
    val bg by animateColorAsState(if (checked) c.acc else Color.Transparent, tweenSpec(220), label = "chk")
    Box(
        Modifier.size(28.dp).clip(CircleShape).background(bg)
            .border(2.dp, if (checked) c.acc else c.sub.copy(alpha = 0.5f), CircleShape)
            .pressable(scaleTo = 0.85f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { if (checked) Icon(Ic.Check, c.onAcc, 16.dp) }
}

@Composable
fun EmptyCard(emoji: String, title: String, sub: String, modifier: Modifier = Modifier, actions: @Composable ColumnScope.() -> Unit = {}) {
    AppCard(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Tx(emoji, size = 40.sp, overflow = TextOverflow.Clip)
            Tx(title, Modifier.padding(top = 8.dp), size = 17.sp, weight = FontWeight.Bold, align = TextAlign.Center)
            Tx(sub, Modifier.padding(top = 6.dp, bottom = 12.dp), size = 13.5.sp, color = Th.c.sub, align = TextAlign.Center)
            actions()
        }
    }
}

// ====================================================================== chips
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color? = null) {
    val c = Th.c
    val tint = color ?: c.acc
    val bg by animateColorAsState(if (selected) tint.copy(alpha = if (c.light) 0.16f else 0.22f) else c.surface2, tweenSpec(200), label = "chipbg")
    val fg by animateColorAsState(if (selected) (if (c.light) lerpDark(tint) else tint) else c.sub, tweenSpec(200), label = "chipfg")
    Box(
        modifier.clip(RoundedCornerShape(50)).background(bg)
            .border(1.dp, if (selected) tint.copy(alpha = 0.55f) else Color.Transparent, RoundedCornerShape(50))
            .pressable(scaleTo = 0.94f, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Tx(text, size = 13.5.sp, weight = FontWeight.Medium, color = fg, maxLines = 1) }
}

private fun lerpDark(c: Color): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, 0.3f)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipFlow(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    FlowRow(
        modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
fun ChipScroll(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = content
    )
}

@Composable
fun Label(text: String, modifier: Modifier = Modifier) {
    Tx(text, modifier.padding(top = 16.dp, bottom = 8.dp, start = 2.dp), size = 12.5.sp, weight = FontWeight.SemiBold, color = Th.c.sub)
}

// ====================================================================== segmented
@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val c = Th.c
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(c.surface2).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        options.forEach { (k, label) ->
            val on = k == selected
            val bg by animateColorAsState(if (on) c.surface else Color.Transparent, tweenSpec(220), label = "segbg")
            val fg by animateColorAsState(if (on) c.text else c.sub, tweenSpec(220), label = "segfg")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(50)).background(bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(k) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Tx(label, size = 13.5.sp, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = fg, maxLines = 1) }
        }
    }
}

// ====================================================================== buttons
enum class BtnKind { Primary, Ghost, Danger, Soft }

@Composable
fun Btn(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.Primary,
    icon: Ic? = null,
    enabled: Boolean = true,
    big: Boolean = false
) {
    val c = Th.c
    val d = Th.d
    val shape = RoundedCornerShape(if (d.coloros) 16.dp else 50.dp)
    val (bg, fg) = when (kind) {
        BtnKind.Primary -> c.acc to c.onAcc
        BtnKind.Ghost -> c.surface2 to c.text
        BtnKind.Danger -> c.bad.copy(alpha = 0.15f) to c.bad
        BtnKind.Soft -> c.accSoft to c.accText
    }
    Row(
        modifier.clip(shape).background(bg).alpha(if (enabled) 1f else 0.45f)
            .pressable(enabled = enabled, scaleTo = 0.95f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = if (big) 16.dp else 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, fg, if (big) 22.dp else 18.dp); Spacer(Modifier.width(8.dp)) }
        Tx(text, size = if (big) 16.5.sp else 14.5.sp, weight = FontWeight.SemiBold, color = fg, maxLines = 1)
    }
}

@Composable
fun IconBtn(ic: Ic, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Color.Unspecified, size: Dp = 40.dp, bg: Color? = null) {
    val t = if (tint == Color.Unspecified) Th.c.text else tint
    Box(
        modifier.size(size).clip(CircleShape).then(if (bg != null) Modifier.background(bg) else Modifier)
            .pressable(scaleTo = 0.86f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(ic, t, (size.value * 0.52f).dp) }
}

@Composable
fun OneSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Th.c
    val track by animateColorAsState(if (checked) c.acc else c.surface2, tweenSpec(220), label = "swt")
    val x by animateDpAsState(if (checked) 22.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium), label = "swx")
    Box(
        Modifier.width(52.dp).height(30.dp).clip(RoundedCornerShape(50)).background(track)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(Modifier.offset(x = x).size(24.dp).shadow(2.dp, CircleShape).clip(CircleShape).background(if (checked) c.onAcc else if (c.light) Color.White else c.sub))
    }
}

@Composable
fun SettingRow(title: String, sub: String? = null, modifier: Modifier = Modifier, trailing: @Composable () -> Unit) {
    Row(modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(title, size = 15.sp, weight = FontWeight.Medium)
            if (sub != null) Tx(sub, Modifier.padding(top = 2.dp), size = 12.sp, color = Th.c.sub)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
fun Stepper(onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconBtnText("−", onMinus)
        IconBtnText("+", onPlus)
    }
}

@Composable
fun IconBtnText(t: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(Th.c.surface2).pressable(scaleTo = 0.86f, onClick = onClick), contentAlignment = Alignment.Center) {
        Tx(t, size = 20.sp, weight = FontWeight.SemiBold, overflow = TextOverflow.Clip)
    }
}

// ====================================================================== inputs
@Composable
fun Field(
    value: String,
    onValue: (String) -> Unit,
    modifier: Modifier = Modifier,
    hint: String = "",
    keyboard: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
    maxLen: Int = 500,
    center: Boolean = false
) {
    val c = Th.c
    val d = Th.d
    BasicTextField(
        value = value, onValueChange = { if (it.length <= maxLen) onValue(it) }, singleLine = singleLine,
        minLines = if (singleLine) 1 else minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        textStyle = TextStyle(color = c.text, fontSize = 15.sp, fontFamily = LocalAppFont.current, textAlign = if (center) TextAlign.Center else TextAlign.Start),
        cursorBrush = SolidColor(c.acc),
        modifier = modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(d.inner)).background(c.surface2).padding(horizontal = 14.dp, vertical = 13.dp),
                contentAlignment = if (center) Alignment.Center else Alignment.CenterStart
            ) {
                if (value.isEmpty() && hint.isNotEmpty()) Tx(hint, size = 15.sp, color = c.sub.copy(alpha = 0.7f), maxLines = 1)
                inner()
            }
        }
    )
}

private fun pickerTheme(light: Boolean): Int =
    if (light) android.R.style.Theme_Material_Light_Dialog_Alert else android.R.style.Theme_Material_Dialog_Alert

@Composable
fun PickBox(text: String, placeholder: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = Th.c
    Box(
        modifier.fillMaxWidth().clip(RoundedCornerShape(Th.d.inner)).background(c.surface2)
            .pressable(scaleTo = 0.98f, onClick = onClick).padding(horizontal = 14.dp, vertical = 13.dp)
    ) { Tx(text.ifEmpty { placeholder }, size = 15.sp, color = if (text.isEmpty()) c.sub.copy(alpha = 0.7f) else c.text, maxLines = 1) }
}

/** Native Android date dialog; value is an ISO date. */
@Composable
fun DateField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, max: String? = null, placeholder: String = "Date chuno", allowClear: Boolean = false) {
    val ctx = LocalContext.current
    val light = Th.c.light
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        PickBox(
            if (isValidDate(value)) fmtD(value) + " " + parseD(value).year else "", placeholder, Modifier.weight(1f)
        ) {
            val d = if (isValidDate(value)) parseD(value) else java.time.LocalDate.now()
            val dlg = DatePickerDialog(ctx, pickerTheme(light), { _, y, m, day -> onChange("$y-${pad2(m + 1)}-${pad2(day)}") }, d.year, d.monthValue - 1, d.dayOfMonth)
            if (max != null && isValidDate(max)) {
                dlg.datePicker.maxDate = parseD(max).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() + 86_399_000L
            }
            dlg.show()
        }
        if (allowClear && value.isNotEmpty()) { Spacer(Modifier.width(6.dp)); IconBtn(Ic.Close, { onChange("") }, size = 38.dp) }
    }
}

@Composable
fun TimeField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, placeholder: String = "Time chuno", allowClear: Boolean = false) {
    val ctx = LocalContext.current
    val light = Th.c.light
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        PickBox(to12(value), placeholder, Modifier.weight(1f)) {
            val p = value.split(":")
            val h = p.getOrNull(0)?.toIntOrNull() ?: 6
            val m = p.getOrNull(1)?.toIntOrNull() ?: 0
            TimePickerDialog(ctx, pickerTheme(light), { _, hh, mm -> onChange("${pad2(hh)}:${pad2(mm)}") }, h, m, false).show()
        }
        if (allowClear && value.isNotEmpty()) { Spacer(Modifier.width(6.dp)); IconBtn(Ic.Close, { onChange("") }, size = 38.dp) }
    }
}

@Composable
fun Swatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    val c = Th.c
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(color)
            .border(if (selected) 3.dp else 0.dp, if (selected) c.text else Color.Transparent, CircleShape)
            .pressable(scaleTo = 0.88f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { if (selected) Icon(Ic.Check, Color.White, 18.dp) }
}

@Composable
fun Spacer8() = Spacer(Modifier.height(8.dp))

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun Hint(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().clip(RoundedCornerShape(Th.d.inner)).background(Th.c.accSoft).padding(12.dp)) {
        Tx(text, size = 13.sp, color = Th.c.accText, weight = FontWeight.Medium)
    }
}

@Composable
fun WidthLimited(content: @Composable () -> Unit) {
    Box(Modifier.widthIn(max = 640.dp)) { content() }
}
