# Lakshya – Study Companion (native Android)

Jetpack Compose app, One UI / ColorOS style. Purane WebView app ke saare features + naye extras.

## Features
- Home: greeting, level/XP, exam countdown, daily-goal ring, streak, aaj ke tasks, revision due, focus areas, syllabus forecast
- Planner (smart plan, carry-over) + weekly Timetable (clash detection) + Habits
- Focus timer: Pomodoro / free, background me chalta hai (alarm + notification chronometer), distraction counter, manual time
- Syllabus (SSC MTS preset), topic status, spaced revision (1-3-7-14-30-60 din)
- Mock tests (+1 / −0.25 marking), merit score, galti logging, Analysis (trend, reasons donut, weak topics, subject×reason grid, insights)
- Notebook + flip flashcards (Leitner boxes)
- Stats (bar, donut, heatmap, best time of day, records), 22 badges, XP levels
- Settings: Pomodoro, marking scheme, daily reminder, backup / restore (.json), demo data
- Look: One UI ↔ ColorOS, 11 themes (Auto light/dark), wallpaper accent (Android 12+), card style, corners, font, text size, density, nav style, animations Full/Lite/Off

## Build
**Option A – Android Studio:** open this folder → Sync → Run (ya Build ▸ Build APK).
**Option B – GitHub (no setup):** repo me upload karo → Actions ▸ *Build APK* → Releases se `Lakshya-release.apk` download karo (release = R8 optimised, sabse smooth).

JDK 17, compileSdk 35, minSdk 26.

## Purane app ka data
Package naya hai (`com.lakshya.study`), isliye purana app alag rehta hai. Purane app se *Backup* (.json) lo → naye app me **Settings ▸ Backup restore** (ya onboarding screen par). Format same hai.

## Note
Ye code is environment me compile nahi ho saka (Android SDK nahi tha). Core logic (`core/`) compile + test ho chuka hai; UI layer static review se check hui hai. Agar build me koi error aaye to error text bhej do, turant fix ho jayega.
